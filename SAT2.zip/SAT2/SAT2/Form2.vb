﻿Imports System.Xml

Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Disables user from being able to return to main form without closing or finishing operation on 2nd form
        Form1.Enabled = False
        SetPage()
    End Sub

    Private Sub Form2_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Ensures user can interact with main form if 2nd form closes unexpectedly
        Form1.Enabled = True
    End Sub

    Private Sub ClearPage()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Hides all objects on form
        Dim Ctrl As Control = Me
        For Each ChildCtrl As Control In Ctrl.Controls
            ChildCtrl.Visible = False
        Next

    End Sub
    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Activates subroutines to show controls relevant to the current task
        If Form1.strCurrentPopUp = "SubmitDrive" Or Form1.strCurrentPopUp = "SubmitDriveM" Then
            SubmitDrive()
        ElseIf Form1.strCurrentPopUp = "AddCar" Then
            AddCar()
        ElseIf Form1.strCurrentPopUp = "AddBooking" Then
            AddBooking()
        End If
    End Sub


    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Closes page
        Me_Close()
    End Sub

    Private Sub SetPage()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''This whole section is simple, just shows the control relevant to what the form is doing and adds items to comboboxes
        ClearPage()
        If Form1.strCurrentPopUp = "SubmitDrive" Or Form1.strCurrentPopUp = "SubmitDriveM" Then
            Dim strTimeElapsed() As String = Form1.lblTimeElapsed.Text.Split(":")
            lblDriveInfoLabelHours.Visible = True
            lblDriveInfoLabelMinutes.Visible = True
            lblDriveInfoLabelTime.Visible = True
            lblDriveInfoLabelSeconds.Visible = True
            cbxHours.Visible = True
            cbxMinutes.Visible = True
            cbxSeconds.Visible = True
            btnYes.Visible = True
            btnYes.Text = "Submit"
            btnCancel.Visible = True
            btnCancel.Text = "Cancel"
            lblPageName.Visible = True
            lblPageName.Text = "Submit Drive"
            cbxHours.Items.Clear()
            cbxMinutes.Items.Clear()
            For x = 0 To 59

                cbxMinutes.Items.Add(x.ToString())
                cbxSeconds.Items.Add(x.ToString())
                If x < 24 Then
                    cbxHours.Items.Add(x.ToString())
                End If
            Next
            cbxHours.SelectedIndex = strTimeElapsed(0)
            cbxMinutes.SelectedIndex = strTimeElapsed(1)
            cbxSeconds.SelectedIndex = strTimeElapsed(2)
        ElseIf Form1.strCurrentPopUp = "AddCar" Then
            lblPageName.Visible = True
            lblPageName.Text = "Add New Car"
            lblCarName.Visible = True
            txtCarName.Visible = True
            btnYes.Visible = True
            btnCancel.Visible = True
            btnYes.Text = "Add Car"
            btnCancel.Text = "Cancel"
        ElseIf Form1.strCurrentPopUp = "AddBooking" Then
            lblBookingName.Visible = True
            txtBookingName.Visible = True
            dtpDate.Visible = True
            cbxTimeStart.Visible = True
            cbxTimeEnd.Visible = True
            chxRecurring.Visible = True
            cbxRecurringFrequency.Visible = True
            btnYes.Visible = True
            btnCancel.Visible = True
            lblTo.Visible = True
            lblPageName.Visible = True
            lblPageName.Text = "Add Booking"
            btnYes.Text = "Save"
            btnCancel.Text = "Cancel"
        End If
    End Sub



    Private Sub SubmitDrive()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Adds record to xml, no validation needed as this form isnt activated unless validation is completed
        Dim xmlDoc As XDocument = XDocument.Load($"Cars\{Form1.strCurrentUserCarName(1)}\drives.xml")
        Dim newDriveNode = New XElement("drive")
        Dim driverElement
        If Form1.strCurrentPopUp = "SubmitDrive" Then
            driverElement = New XElement("Driver", Form1.strCurrentUserCarName(2))
        Else
            driverElement = New XElement("Driver", Form1.cbxDriver.SelectedItem)
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Convertto2dstring is function in SATFunctions which turns values like 9 2 3 into 09 02 03 to make better looking dates
        Dim driveTimeElement = New XElement("drive_time", $"{ConvertTo2DString(cbxHours.SelectedIndex)}:{ConvertTo2DString(cbxMinutes.SelectedIndex)}:{ConvertTo2DString(cbxSeconds.SelectedIndex)}")
        Dim driveDateElement = New XElement("drive_date", Convert.ToString(Date.Now).Split(" ")(0))
        newDriveNode.Add(driverElement, driveTimeElement, driveDateElement)
        xmlDoc.Root.Add(newDriveNode)
        xmlDoc.Save($"Cars\{Form1.strCurrentUserCarName(1)}\drives.xml")
        MsgBox("Success! Your drive was submitted.")
        Form1.lblTimeElapsed.Text = "00:00:00"
        Form1.boolDriveActive = False
        Form1.tmrTimeUpdate.Stop()
        Form1.SetPage()
        Form1.btnStartDrive.BackColor = Color.LimeGreen
        Form1.cbxHours.SelectedIndex = 0
        Form1.cbxHours.SelectedIndex = 0

        Me_Close()
    End Sub

    Private Sub AddCar()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Uses text validation function on Car name user entry
        If ValidateText(txtCarName.Text, "Car Name", "=+{[}]`~\|/?.>,<:;", 2, 24) = "" Then
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Checks if car is already exists
            Dim di As New IO.DirectoryInfo("Cars")
            Dim aryDi As IO.DirectoryInfo() = di.GetDirectories()
            Dim fdi As IO.DirectoryInfo
            Dim boolFound As Boolean = False
            For Each fdi In aryDi
                If fdi.Name = txtCarName.Text Then
                    boolFound = True
                End If
            Next
            If boolFound Then
                MsgBox("There is already are car with that name. Please choose a different name.")
            Else
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Creates xml documents for new car
                di.CreateSubdirectory(txtCarName.Text)
                Dim xmlDoc As XDocument = <?xml version="1.0" encoding="utf-8"?>
                                          <drive-information>

                                          </drive-information>
                xmlDoc.Save($"Cars\{txtCarName.Text}\drives.xml")
                xmlDoc = <?xml version="1.0" encoding="utf-8"?>
                         <bookings>

                         </bookings>
                xmlDoc.Save($"Cars\{txtCarName.Text}\calendar.xml")
                xmlDoc = <?xml version="1.0" encoding="utf-8"?>
                         <car_refuel_information>

                         </car_refuel_information>
                xmlDoc.Save($"Cars\{txtCarName.Text}\refuels.xml")
                Form1.Refresh_lbxCars()
                Me_Close()
            End If
        Else
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''sends error message if validation failed
            MsgBox(ValidateText(txtCarName.Text, "Car Name", "=+{[}]`~\|/?.>,<:;", 2, 24))
        End If
    End Sub

    Private Sub AddBooking()

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''' Validation!!
        If ValidateText(txtBookingName.Text, "Booking Name", "", 2, 30) <> "" Then
            MsgBox(ValidateText(txtBookingName.Text, "Booking Name", "", 2, 30))
        ElseIf cbxTimeStart.SelectedIndex = -1 Or cbxTimeEnd.SelectedIndex = -1 Then
            MsgBox("Please make sure you have selected a start and end time")
        ElseIf chxRecurring.Checked = True AndAlso cbxRecurringFrequency.SelectedIndex = -1 Then
            MsgBox("You have checked that your booking should be recurring, please select a recurring frequency from the drop down menu below")
        Else

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Creates Record
            Dim xmlDoc As XDocument = XDocument.Load($"Cars\{Form1.strCurrentUserCarName(1)}\calendar.xml")
            Dim newBookingNode = New XElement("booking")
            Dim RecurringElement
            If chxRecurring.Checked = True Then
                If cbxRecurringFrequency.SelectedIndex = 0 Then
                    RecurringElement = New XElement("recurring", 7)
                ElseIf cbxRecurringFrequency.SelectedIndex = 1 Then
                    RecurringElement = New XElement("recurring", 14)
                Else
                    RecurringElement = New XElement("recurring", 0)
                End If
            Else
                RecurringElement = New XElement("recurring", 0)
            End If
            Dim userElement = New XElement("user", Form1.strCurrentUserCarName(2))
            Dim dateElement = New XElement("booking_date", dtpDate.Value.ToString("dd/MM/yyyy"))
            Dim startElement = New XElement("booking_start_time", cbxTimeStart.SelectedItem())
            Dim endElement = New XElement("booking_end_time", cbxTimeEnd.SelectedItem())
            newBookingNode.Add(RecurringElement, userElement, dateElement, startElement, endElement)
            xmlDoc.Root.Add(newBookingNode)
            xmlDoc.Save($"Cars\{Form1.strCurrentUserCarName(1)}\calendar.xml")
            Dim recurring As String
            If cbxRecurringFrequency.SelectedIndex = -1 Then
                recurring = "never"
            Else
                recurring = cbxRecurringFrequency.SelectedItem
            End If
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sends confirmation message to user
            MsgBox($"Success! Your booking for {cbxTimeStart.SelectedItem} to {cbxTimeEnd.SelectedItem} on the {dtpDate.Value.ToString("dd/MM/yyyy")} recurring {recurring} was successful.")
            Form1.SetPage()
            Me_Close()
        End If
    End Sub

    Private Sub Me_Close()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Refocuses main form
        Form1.Enabled = True
        Me.Close()
    End Sub


End Class