﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblPageName = New System.Windows.Forms.Label()
        Me.txtCarName = New System.Windows.Forms.TextBox()
        Me.lblCarName = New System.Windows.Forms.Label()
        Me.btnYes = New System.Windows.Forms.Button()
        Me.btnNo = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.lblDriveInfoLabelMinutes = New System.Windows.Forms.Label()
        Me.lblDriveInfoLabelHours = New System.Windows.Forms.Label()
        Me.cbxMinutes = New System.Windows.Forms.ComboBox()
        Me.cbxHours = New System.Windows.Forms.ComboBox()
        Me.lblDriveInfoLabelTime = New System.Windows.Forms.Label()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.cbxTimeStart = New System.Windows.Forms.ComboBox()
        Me.cbxTimeEnd = New System.Windows.Forms.ComboBox()
        Me.txtBookingName = New System.Windows.Forms.TextBox()
        Me.lblBookingName = New System.Windows.Forms.Label()
        Me.chxRecurring = New System.Windows.Forms.CheckBox()
        Me.cbxRecurringFrequency = New System.Windows.Forms.ComboBox()
        Me.cbxSeconds = New System.Windows.Forms.ComboBox()
        Me.lblDriveInfoLabelSeconds = New System.Windows.Forms.Label()
        Me.lblTo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblPageName
        '
        Me.lblPageName.AutoSize = True
        Me.lblPageName.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPageName.Location = New System.Drawing.Point(74, 9)
        Me.lblPageName.Name = "lblPageName"
        Me.lblPageName.Size = New System.Drawing.Size(209, 37)
        Me.lblPageName.TabIndex = 36
        Me.lblPageName.Text = "Add New Car"
        Me.lblPageName.Visible = False
        '
        'txtCarName
        '
        Me.txtCarName.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCarName.Location = New System.Drawing.Point(96, 100)
        Me.txtCarName.Name = "txtCarName"
        Me.txtCarName.Size = New System.Drawing.Size(230, 44)
        Me.txtCarName.TabIndex = 37
        Me.txtCarName.Visible = False
        '
        'lblCarName
        '
        Me.lblCarName.AutoSize = True
        Me.lblCarName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCarName.Location = New System.Drawing.Point(12, 117)
        Me.lblCarName.Name = "lblCarName"
        Me.lblCarName.Size = New System.Drawing.Size(80, 18)
        Me.lblCarName.TabIndex = 38
        Me.lblCarName.Text = "Car Name:"
        Me.lblCarName.Visible = False
        '
        'btnYes
        '
        Me.btnYes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnYes.Location = New System.Drawing.Point(303, 225)
        Me.btnYes.Name = "btnYes"
        Me.btnYes.Size = New System.Drawing.Size(276, 103)
        Me.btnYes.TabIndex = 49
        Me.btnYes.Text = "Add Car"
        Me.btnYes.UseVisualStyleBackColor = True
        Me.btnYes.Visible = False
        '
        'btnNo
        '
        Me.btnNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNo.Location = New System.Drawing.Point(15, 225)
        Me.btnNo.Name = "btnNo"
        Me.btnNo.Size = New System.Drawing.Size(282, 103)
        Me.btnNo.TabIndex = 50
        Me.btnNo.Text = "Add Car"
        Me.btnNo.UseVisualStyleBackColor = True
        Me.btnNo.Visible = False
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(15, 286)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(132, 42)
        Me.btnCancel.TabIndex = 51
        Me.btnCancel.Text = "Add Car"
        Me.btnCancel.UseVisualStyleBackColor = True
        Me.btnCancel.Visible = False
        '
        'btnOk
        '
        Me.btnOk.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOk.Location = New System.Drawing.Point(447, 286)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(132, 42)
        Me.btnOk.TabIndex = 52
        Me.btnOk.Text = "Add Car"
        Me.btnOk.UseVisualStyleBackColor = True
        Me.btnOk.Visible = False
        '
        'lblDriveInfoLabelMinutes
        '
        Me.lblDriveInfoLabelMinutes.AutoSize = True
        Me.lblDriveInfoLabelMinutes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblDriveInfoLabelMinutes.Location = New System.Drawing.Point(244, 87)
        Me.lblDriveInfoLabelMinutes.Name = "lblDriveInfoLabelMinutes"
        Me.lblDriveInfoLabelMinutes.Size = New System.Drawing.Size(65, 20)
        Me.lblDriveInfoLabelMinutes.TabIndex = 59
        Me.lblDriveInfoLabelMinutes.Text = "minutes"
        Me.lblDriveInfoLabelMinutes.Visible = False
        '
        'lblDriveInfoLabelHours
        '
        Me.lblDriveInfoLabelHours.AutoSize = True
        Me.lblDriveInfoLabelHours.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblDriveInfoLabelHours.Location = New System.Drawing.Point(153, 88)
        Me.lblDriveInfoLabelHours.Name = "lblDriveInfoLabelHours"
        Me.lblDriveInfoLabelHours.Size = New System.Drawing.Size(53, 20)
        Me.lblDriveInfoLabelHours.TabIndex = 58
        Me.lblDriveInfoLabelHours.Text = "hours "
        Me.lblDriveInfoLabelHours.Visible = False
        '
        'cbxMinutes
        '
        Me.cbxMinutes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxMinutes.DropDownWidth = 103
        Me.cbxMinutes.FormattingEnabled = True
        Me.cbxMinutes.Location = New System.Drawing.Point(202, 86)
        Me.cbxMinutes.Name = "cbxMinutes"
        Me.cbxMinutes.Size = New System.Drawing.Size(36, 21)
        Me.cbxMinutes.TabIndex = 56
        Me.cbxMinutes.Visible = False
        '
        'cbxHours
        '
        Me.cbxHours.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxHours.DropDownWidth = 103
        Me.cbxHours.FormattingEnabled = True
        Me.cbxHours.Location = New System.Drawing.Point(105, 87)
        Me.cbxHours.Name = "cbxHours"
        Me.cbxHours.Size = New System.Drawing.Size(42, 21)
        Me.cbxHours.TabIndex = 55
        Me.cbxHours.Visible = False
        '
        'lblDriveInfoLabelTime
        '
        Me.lblDriveInfoLabelTime.AutoSize = True
        Me.lblDriveInfoLabelTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDriveInfoLabelTime.Location = New System.Drawing.Point(30, 87)
        Me.lblDriveInfoLabelTime.Name = "lblDriveInfoLabelTime"
        Me.lblDriveInfoLabelTime.Size = New System.Drawing.Size(81, 20)
        Me.lblDriveInfoLabelTime.TabIndex = 57
        Me.lblDriveInfoLabelTime.Text = "Drive was "
        Me.lblDriveInfoLabelTime.Visible = False
        '
        'dtpDate
        '
        Me.dtpDate.Location = New System.Drawing.Point(379, 73)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(200, 20)
        Me.dtpDate.TabIndex = 60
        '
        'cbxTimeStart
        '
        Me.cbxTimeStart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTimeStart.FormattingEnabled = True
        Me.cbxTimeStart.Items.AddRange(New Object() {"00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30"})
        Me.cbxTimeStart.Location = New System.Drawing.Point(378, 109)
        Me.cbxTimeStart.Name = "cbxTimeStart"
        Me.cbxTimeStart.Size = New System.Drawing.Size(69, 21)
        Me.cbxTimeStart.TabIndex = 61
        '
        'cbxTimeEnd
        '
        Me.cbxTimeEnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTimeEnd.FormattingEnabled = True
        Me.cbxTimeEnd.Items.AddRange(New Object() {"00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30"})
        Me.cbxTimeEnd.Location = New System.Drawing.Point(510, 109)
        Me.cbxTimeEnd.Name = "cbxTimeEnd"
        Me.cbxTimeEnd.Size = New System.Drawing.Size(69, 21)
        Me.cbxTimeEnd.TabIndex = 62
        '
        'txtBookingName
        '
        Me.txtBookingName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBookingName.Location = New System.Drawing.Point(117, 63)
        Me.txtBookingName.Name = "txtBookingName"
        Me.txtBookingName.Size = New System.Drawing.Size(209, 31)
        Me.txtBookingName.TabIndex = 63
        Me.txtBookingName.Visible = False
        '
        'lblBookingName
        '
        Me.lblBookingName.AutoSize = True
        Me.lblBookingName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBookingName.Location = New System.Drawing.Point(0, 75)
        Me.lblBookingName.Name = "lblBookingName"
        Me.lblBookingName.Size = New System.Drawing.Size(111, 18)
        Me.lblBookingName.TabIndex = 64
        Me.lblBookingName.Text = "Booking Name:"
        Me.lblBookingName.Visible = False
        '
        'chxRecurring
        '
        Me.chxRecurring.AutoSize = True
        Me.chxRecurring.Location = New System.Drawing.Point(15, 161)
        Me.chxRecurring.Name = "chxRecurring"
        Me.chxRecurring.Size = New System.Drawing.Size(91, 17)
        Me.chxRecurring.TabIndex = 65
        Me.chxRecurring.Text = "Set Recurring"
        Me.chxRecurring.UseVisualStyleBackColor = True
        '
        'cbxRecurringFrequency
        '
        Me.cbxRecurringFrequency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxRecurringFrequency.FormattingEnabled = True
        Me.cbxRecurringFrequency.Items.AddRange(New Object() {"Weekly", "Fortnightly"})
        Me.cbxRecurringFrequency.Location = New System.Drawing.Point(13, 192)
        Me.cbxRecurringFrequency.Name = "cbxRecurringFrequency"
        Me.cbxRecurringFrequency.Size = New System.Drawing.Size(144, 21)
        Me.cbxRecurringFrequency.TabIndex = 66
        '
        'cbxSeconds
        '
        Me.cbxSeconds.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxSeconds.DropDownWidth = 103
        Me.cbxSeconds.FormattingEnabled = True
        Me.cbxSeconds.Location = New System.Drawing.Point(315, 86)
        Me.cbxSeconds.Name = "cbxSeconds"
        Me.cbxSeconds.Size = New System.Drawing.Size(34, 21)
        Me.cbxSeconds.TabIndex = 67
        Me.cbxSeconds.Visible = False
        '
        'lblDriveInfoLabelSeconds
        '
        Me.lblDriveInfoLabelSeconds.AutoSize = True
        Me.lblDriveInfoLabelSeconds.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblDriveInfoLabelSeconds.Location = New System.Drawing.Point(355, 84)
        Me.lblDriveInfoLabelSeconds.Name = "lblDriveInfoLabelSeconds"
        Me.lblDriveInfoLabelSeconds.Size = New System.Drawing.Size(69, 20)
        Me.lblDriveInfoLabelSeconds.TabIndex = 68
        Me.lblDriveInfoLabelSeconds.Text = "seconds"
        Me.lblDriveInfoLabelSeconds.Visible = False
        '
        'lblTo
        '
        Me.lblTo.AutoSize = True
        Me.lblTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTo.Location = New System.Drawing.Point(467, 112)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.Size = New System.Drawing.Size(21, 18)
        Me.lblTo.TabIndex = 69
        Me.lblTo.Text = "to"
        Me.lblTo.Visible = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(608, 351)
        Me.Controls.Add(Me.lblTo)
        Me.Controls.Add(Me.lblDriveInfoLabelSeconds)
        Me.Controls.Add(Me.cbxSeconds)
        Me.Controls.Add(Me.cbxRecurringFrequency)
        Me.Controls.Add(Me.chxRecurring)
        Me.Controls.Add(Me.lblBookingName)
        Me.Controls.Add(Me.txtBookingName)
        Me.Controls.Add(Me.cbxTimeEnd)
        Me.Controls.Add(Me.cbxTimeStart)
        Me.Controls.Add(Me.dtpDate)
        Me.Controls.Add(Me.lblDriveInfoLabelMinutes)
        Me.Controls.Add(Me.cbxMinutes)
        Me.Controls.Add(Me.cbxHours)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnNo)
        Me.Controls.Add(Me.btnYes)
        Me.Controls.Add(Me.lblCarName)
        Me.Controls.Add(Me.txtCarName)
        Me.Controls.Add(Me.lblPageName)
        Me.Controls.Add(Me.lblDriveInfoLabelHours)
        Me.Controls.Add(Me.lblDriveInfoLabelTime)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblPageName As Label
    Friend WithEvents txtCarName As TextBox
    Friend WithEvents lblCarName As Label
    Friend WithEvents btnYes As Button
    Friend WithEvents btnNo As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnOk As Button
    Friend WithEvents lblDriveInfoLabelMinutes As Label
    Friend WithEvents lblDriveInfoLabelHours As Label
    Friend WithEvents cbxMinutes As ComboBox
    Friend WithEvents cbxHours As ComboBox
    Friend WithEvents lblDriveInfoLabelTime As Label
    Friend WithEvents dtpDate As DateTimePicker
    Friend WithEvents cbxTimeStart As ComboBox
    Friend WithEvents cbxTimeEnd As ComboBox
    Friend WithEvents txtBookingName As TextBox
    Friend WithEvents lblBookingName As Label
    Friend WithEvents chxRecurring As CheckBox
    Friend WithEvents cbxRecurringFrequency As ComboBox
    Friend WithEvents cbxSeconds As ComboBox
    Friend WithEvents lblDriveInfoLabelSeconds As Label
    Friend WithEvents lblTo As Label
End Class
