﻿Imports System.IO
Imports System.Xml
Imports Microsoft.VisualBasic.ApplicationServices

Public Class Form1
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Declare Variables
    Dim strCurrentForm As String
    Public strCurrentPopUp As String
    Public strCurrentUserCarName(2) As String
    Dim CalendarCtrlDict As New Dictionary(Of String, RichTextBox)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Adds values to comboboxes and sets values
        For x = 0 To 59
            cbxMinutes.Items.Add(x.ToString())
            If x < 24 Then
                cbxHours.Items.Add(x.ToString())
            End If
        Next
        cbxMinutes.SelectedIndex = 0
        cbxHours.SelectedIndex = 0
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sets Current page value
        strCurrentForm = "StartPage"

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Prepares Calendar control structure
        FillCalendarCtrlDict()

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Updates visible controls to match current page value
        SetPage()

    End Sub
    Private Sub btnLoginPage_Click(sender As Object, e As EventArgs) Handles btnLoginPage.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sets Current page value and updates visible controls to match current page value
        strCurrentForm = "LogIn"
        SetPage()
    End Sub
    Private Sub btnSignUpPage_Click(sender As Object, e As EventArgs) Handles btnSignUpPage.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sets Current page value and updates visible controls to match current page value
        strCurrentForm = "SignUp"
        SetPage()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sets Current page value and updates visible controls to match current page value
        If strCurrentForm = "LogIn" Then
            strCurrentForm = "StartPage"
            SetPage()
        ElseIf strCurrentForm = "SignUp" Then
            strCurrentForm = "StartPage"
            SetPage()
        ElseIf strCurrentForm = "Dashboard" Then
            strCurrentForm = "CarSelect"
            SetPage()
        ElseIf strCurrentForm = "Refuel" Or strCurrentForm = "Notes" Or strCurrentForm = "AddDrive" Or strCurrentForm = "Calendar" Then
            strCurrentForm = "Dashboard"
            SetPage()
        End If
    End Sub

    Private Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Determines number of users currently holding accounts
        Dim intCount As Integer = 0
        Dim ReaderControl As XmlReader = XmlReader.Create("UserData.Xml")
        Do While ReaderControl.Read()
            If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Username" Then
                intCount += 1
            End If
        Loop
        ReaderControl.Close()

        Dim aryUserPass(intCount - 1, 2) As String
        intCount = 0
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Imports usernames, passwords and names in order to check if it matches what user has entered
        ReaderControl = XmlReader.Create("UserData.Xml")
        Do While ReaderControl.Read()
            If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Username" Then
                aryUserPass(intCount, 0) = ReaderControl.ReadElementContentAsString

            ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Name" Then
                aryUserPass(intCount, 2) = ReaderControl.ReadElementContentAsString

            ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Password" Then
                aryUserPass(intCount, 1) = (ReaderControl.ReadElementContentAsString)
                intCount += 1
            End If
        Loop
        ReaderControl.Close()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Validation
        If ValidateText(txtUsername.Text, "Username", " ", 4, 20) <> "" Then
            If ValidateText(txtPassword.Text, "Password", " ", 4, 20) <> "" Then
                MsgBox(ValidateText(txtUsername.Text, "Username", " ", 4, 20))
                MsgBox(ValidateText(txtPassword.Text, "Password", " ", 4, 20))
            Else
                MsgBox(ValidateText(txtUsername.Text, "Username", " ", 4, 20))
            End If
        Else
            If ValidateText(txtPassword.Text, "Password", " ", 4, 20) <> "" Then
                MsgBox(ValidateText(txtPassword.Text, "Password", " ", 4, 20))
            Else

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Checks if username and password entered match
                Dim strUsername As String = txtUsername.Text
                Dim strPassword As String = Convert.ToString(Hash(txtPassword.Text))
                Dim boolCheck As Boolean = False
                For x = 0 To Math.Floor(aryUserPass.Length / 3) - 1
                    If aryUserPass(x, 0) = strUsername Then
                        If aryUserPass(x, 1) = strPassword Then
                            strCurrentUserCarName(0) = strUsername
                            strCurrentUserCarName(2) = aryUserPass(x, 2)
                            boolCheck = True
                        End If
                    End If
                Next
                If boolCheck = False Then
                    MsgBox("Username or Password were incorrect")
                Else
                    strCurrentForm = "CarSelect"
                    SetPage()
                End If
            End If
        End If

    End Sub

    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Validation
        If ValidateText(txtSignUpPassword1.Text, "Password", " ", 4, 20) <> "" Then
            If ValidateText(txtSignUpUsername.Text, "Username", " ", 4, 20) <> "" Then
                MsgBox(ValidateText(txtSignUpPassword1.Text, "Password", " ", 4, 20))
                MsgBox(ValidateText(txtSignUpUsername.Text, "Username", " ", 4, 20))
            Else
                MsgBox(ValidateText(txtSignUpPassword1.Text, "Password", " ", 4, 20))

            End If
        ElseIf ValidateText(txtSignUpUsername.Text, "Username", " ", 4, 20) <> "" Then
            MsgBox(ValidateText(txtSignUpUsername.Text, "Username", " ", 4, 20))
        Else
            If ValidateText(txtSignUpUsername.Text, "Name", "", 2, 30) <> "" Then
                MsgBox(ValidateText(txtSignUpUsername.Text, "Name", "", 2, 30))

            Else
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Checks if passwords entered are the same
                Dim strPassCheck1 As String = txtSignUpPassword1.Text
                Dim strPassCheck2 As String = txtSignUpPassword2.Text

                If strPassCheck1 = strPassCheck2 Then
                    Dim Document As XDocument = XDocument.Load("UserData.Xml")
                    Dim UserElement As New XElement("User")
                    Dim UsernameElement = New XElement("Username", txtSignUpUsername.Text)
                    Dim PasswordElement = New XElement("Password", Hash(txtSignUpPassword1.Text))
                    Dim NameElement = New XElement("Name", txtName.Text)
                    UserElement.Add(UsernameElement, NameElement, PasswordElement)
                    Document.Root.Add(UserElement)
                    Document.Save("UserData.Xml")
                    strCurrentUserCarName(0) = txtSignUpUsername.Text
                    strCurrentUserCarName(2) = txtName.Text
                    strCurrentForm = "CarSelect"
                    SetPage()
                Else
                    MsgBox("Passwords do not match, please ensure passwords match")
                End If
            End If
        End If
    End Sub
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Allows double click on listboxes or "select" button
    Private Sub lbxCars_DoubleClick(sender As Object, e As EventArgs) Handles lbxCars.DoubleClick
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sets a currentCar variable and updates page with Controls for dashboard
        If lbxCars.SelectedIndex <> -1 Then
            strCurrentUserCarName(1) = lbxCars.SelectedItem
            strCurrentForm = "Dashboard"
            SetPage()
        End If
    End Sub

    Private Sub btnSelectCar_Click(sender As Object, e As EventArgs) Handles btnSelectCar.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Sets a currentCar variable and updates page with Controls for dashboard
        strCurrentUserCarName(1) = lbxCars.SelectedItem
        strCurrentForm = "Dashboard"
        SetPage()
    End Sub

    Private Sub btnDeleteCar_Click(sender As Object, e As EventArgs) Handles btnDeleteCar.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Checks if user meant to delete car
        Dim Answer As Integer
        Answer = MsgBox($"Are you sure you wish to delete all data for {lbxCars.SelectedItem}?", vbQuestion + vbYesNo + vbDefaultButton2, "Are you sure?")
        If Answer = vbYes Then
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Locates selected cars directory
            Dim di As New IO.DirectoryInfo("Cars")
            Dim aryDi As IO.DirectoryInfo() = di.GetDirectories()
            Dim fdi As IO.DirectoryInfo

            For Each fdi In aryDi
                If fdi.Name = lbxCars.SelectedItem Then
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Deletes Car once found
                    fdi.Delete(True)
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Updates to show to user that car is removed
                    Refresh_lbxCars()
                End If
            Next
        End If
    End Sub

    Private Sub btnAddCar_Click(sender As Object, e As EventArgs) Handles btnAddCar.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Opens form2 with id of AddCar
        strCurrentPopUp = "AddCar"
        Form2.Show()
    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Removes the user value from currentusercarname
        strCurrentUserCarName(0) = ""
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Returns user to the "landing page"
        strCurrentForm = "StartPage"
        SetPage()
    End Sub

    Private Sub cbxCurrentCar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxCurrentCar.SelectedIndexChanged
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Updates current car when user switches in combobox 
        strCurrentUserCarName(1) = cbxCurrentCar.SelectedItem()
        SetPage(True)
    End Sub
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Switches current shown control elements(text boxes buttons, eg) to page user selects
        strCurrentForm = "Dashboard"
        SetPage()
    End Sub

    Private Sub btnCalendar_Click(sender As Object, e As EventArgs) Handles btnCalendar.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''same as previous
        strCurrentForm = "Calendar"
        SetPage()
    End Sub
    Private Sub btnDrives_Click(sender As Object, e As EventArgs) Handles btnDrives.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''same as previous
        strCurrentForm = "AddDrive"
        SetPage()
    End Sub

    Private Sub btnRefuel_Click(sender As Object, e As EventArgs) Handles btnRefuel.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''same as previous
        strCurrentForm = "Refuel"
        SetPage()
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''EnterDrive Page section. Code for control elements which are shown on enter drive page
    Dim driveStartTime As DateTime
    Dim drivePauseTime As DateTime
    Public boolDriveActive As Boolean = False
    Dim boolDrivePause As Boolean = False


    Private Sub cbxHours_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxHours.SelectedIndexChanged
        updateManualDriveSummary(cbxHours.SelectedIndex, cbxMinutes.SelectedIndex, cbxDriver.SelectedItem)
    End Sub

    Private Sub cbxMinutes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxMinutes.SelectedIndexChanged
        updateManualDriveSummary(cbxHours.SelectedIndex, cbxMinutes.SelectedIndex, cbxDriver.SelectedItem)
    End Sub

    Private Sub cbxDriver_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxDriver.SelectedIndexChanged
        updateManualDriveSummary(cbxHours.SelectedIndex, cbxMinutes.SelectedIndex, cbxDriver.SelectedItem)
    End Sub

    Private Sub btnStartDrive_Click(sender As Object, e As EventArgs) Handles btnStartDrive.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Activates timer to update label
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Disables start button
        If boolDriveActive = False Then
            driveStartTime = DateTime.Now()
            Console.WriteLine(btnStartDrive.BackColor)
            btnStartDrive.BackColor = Color.LightGray
            boolDriveActive = True
            tmrTimeUpdate.Start()
        End If
    End Sub

    Private Sub btnEndDrive_Click(sender As Object, e As EventArgs) Handles btnEndDrive.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Opens pop up with submit drive id
        If boolDriveActive = True Then
            strCurrentPopUp = "SubmitDrive"
            Form2.Show()
        End If
    End Sub

    Private Sub btnPauseDrive_Click(sender As Object, e As EventArgs) Handles btnPauseDrive.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Activates pause, records time to add to start time when unpaused to keep the time between start and current the same as pre-pause
        If boolDriveActive = True Then
            If boolDrivePause = False Then
                drivePauseTime = DateTime.Now()
                btnPauseDrive.Text = "Unpause"
                boolDrivePause = True
            Else
                driveStartTime = driveStartTime + (DateTime.Now() - drivePauseTime)
                boolDrivePause = False
                btnPauseDrive.Text = "Pause"
                updateDriveTime(driveStartTime)
            End If
        End If
    End Sub

    Private Sub btnSubmitManual_Click(sender As Object, e As EventArgs) Handles btnSubmitManual.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Existence Validation for combo boxes
        If cbxDriver.SelectedIndex = -1 Then
            MsgBox("Please Select a Driver")
        ElseIf cbxHours.SelectedIndex = 0 AndAlso cbxMinutes.SelectedIndex = 0 Then
            MsgBox("Please enter an amount of time")
        Else
            lblTimeElapsed.Text = $"{cbxHours.SelectedItem}:{cbxMinutes.SelectedItem}:00"
            strCurrentPopUp = "SubmitDriveM"
            Form2.Show()
        End If
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Splits label to get month and year ata
        Dim strListInfo() As String = lblMonth.Text.Split(" ")
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''converts text month into int
        Dim intMonth As Integer = MonthToIndex(strListInfo(0))
        If intMonth = 12 Then
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''updates calendar to next month and next year and january if it is december
            SetCalendar($"05/01/{Convert.ToInt16(strListInfo(1)) + 1}")
        ElseIf intMonth = -1 Then

        Else
            SetCalendar($"05/{ConvertTo2DString(intMonth + 1)}/{strListInfo(1)}")
        End If
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''same as previous but in reverse
        Dim strListInfo() As String = lblMonth.Text.Split(" ")
        Dim intMonth As Integer = MonthToIndex(strListInfo(0))
        If intMonth = 1 Then
            SetCalendar($"05/12/{Convert.ToInt16(strListInfo(1)) - 1}")
        ElseIf intMonth = -1 Then

        Else
            SetCalendar($"05/{ConvertTo2DString(intMonth - 1)}/{strListInfo(1)}")
        End If
    End Sub

    Private Sub btnAddBooking_Click(sender As Object, e As EventArgs) Handles btnAddBooking.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''opens pop up for creating a booking
        strCurrentPopUp = "AddBooking"
        Form2.Show()
    End Sub

    Private Sub nudLitres_ValueChanged(sender As Object, e As EventArgs) Handles nudLitres.ValueChanged
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''updates label for information
        lblRefuelSummary.Text = $"Refueled {nudLitres.Value}L for ${nudPrice.Value} at ${Decimal.Round((nudPrice.Value / nudLitres.Value), 2) } per litre"
    End Sub

    Private Sub nudPrice_ValueChanged(sender As Object, e As EventArgs) Handles nudPrice.ValueChanged
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''same as previous
        lblRefuelSummary.Text = $"Refueled {nudLitres.Value}L for ${nudPrice.Value} at ${Decimal.Round((nudPrice.Value / nudLitres.Value), 2) } per litre"
    End Sub

    Private Sub btnSubmitRefuel_Click(sender As Object, e As EventArgs) Handles btnSubmitRefuel.Click
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Creates Record

        Dim xmlDoc As XDocument = XDocument.Load($"Cars\{strCurrentUserCarName(1)}\refuels.xml")
        Dim newRefuelNode = New XElement("refuel")
        Dim driverElement = New XElement("driver", strCurrentUserCarName(2))

        Dim refuelTime = New XElement("refuel_time", DateTime.Now)

        Dim refuel_price = New XElement("refuel_price", nudPrice.Value)
        Dim refuel_litres = New XElement("refuel_litres", nudLitres.Value)

        newRefuelNode.Add(driverElement, refuelTime, refuel_price, refuel_litres)
        xmlDoc.Root.Add(newRefuelNode)
        xmlDoc.Save($"Cars\{strCurrentUserCarName(1)}\refuels.xml")
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Resets values and provides feedback to users
        nudLitres.Value = 1
        nudPrice.Value = 1
        MsgBox("Success! Refuel Has been submitted!")

    End Sub















    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Subroutine which updates shown control elements to match current page
    Public Sub SetPage(Optional boolCancelRecursive As Boolean = False)
        ClearPage()

        If strCurrentForm = "StartPage" Then
            btnLoginPage.Visible = True
            btnSignUpPage.Visible = True
        ElseIf strCurrentForm = "LogIn" Then
            btnBack.Visible = True
            lblLogIn.Visible = True
            lblLogInPassword.Visible = True
            lblLogInUsername.Visible = True
            txtUsername.Visible = True
            txtPassword.Visible = True
            btnLogin.Visible = True
            txtUsername.Text = ""
            txtPassword.Text = ""
        ElseIf strCurrentForm = "SignUp" Then
            btnBack.Visible = True
            lblSignUp.Visible = True
            lblSignUpName.Visible = True
            lblSignUpUsername.Visible = True
            lblSignUpPassword1.Visible = True
            lblSignUpPassword2.Visible = True
            txtSignUpUsername.Visible = True
            txtSignUpPassword1.Visible = True
            txtSignUpPassword2.Visible = True
            txtName.Visible = True
            btnSignUp.Visible = True
            txtSignUpUsername.Text = ""
            txtSignUpPassword1.Text = ""
            txtSignUpPassword2.Text = ""
            txtName.Text = ""
        ElseIf strCurrentForm = "CarSelect" Then

            lblCarList.Visible = True
            lbxCars.Visible = True
            btnSelectCar.Visible = True
            btnDeleteCar.Visible = True
            btnAddCar.Visible = True
            btnLogOut.Visible = True

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Enter values into cbxDriver on EnterDrive Page, optimal spot to activate as any new users have been added and the entry to this page happens once so all entered values can be reset
            cbxDriver.Items.Clear()
            Dim ReaderControl As XmlReader = XmlReader.Create("UserData.Xml")
            Do While ReaderControl.Read()
                If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Name" Then
                    cbxDriver.Items.Add(ReaderControl.ReadElementContentAsString)
                End If
            Loop
            ReaderControl.Close()

            Refresh_lbxCars()
        ElseIf strCurrentForm = "Dashboard" Then
            SetGenericPage(boolCancelRecursive)
            cbxCurrentCar.SelectedItem = strCurrentUserCarName(1)
            lblPageName.Text = "Dashboard"
            lbxDriverBooking.Visible = True
            lbxDrivers.Visible = True
            lbxCostLitres.Visible = True
            lbxRefuelUser.Visible = True
            lbxBookingsTime.Visible = True
            lbxTimes.Visible = True
            lbxBookingsTime.Visible = True
            lblDrives.Visible = True
            lblRefuels.Visible = True
            lblTodaysBookings.Visible = True
            lbxDriverBooking.Items.Clear()
            lbxDrivers.Items.Clear()
            lbxCostLitres.Items.Clear()
            lbxRefuelUser.Items.Clear()
            lbxBookingsTime.Items.Clear()
            lbxTimes.Items.Clear()
            lbxBookingsTime.Items.Clear()
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''If showing dashboard updates listboxes entering data from various xml files using reader controls
            Dim intCountDrive As Integer = 0
            Dim ReaderControl As XmlReader = XmlReader.Create($"Cars\{cbxCurrentCar.SelectedItem}\drives.xml")
            Do While ReaderControl.Read()
                If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Driver" Then
                    intCountDrive += 1
                End If
            Loop
            ReaderControl.Close()
            If intCountDrive > 10 Then
                Dim startRecent As Integer = intCountDrive - 10
                intCountDrive = 0

                ReaderControl = XmlReader.Create($"Cars\{cbxCurrentCar.SelectedItem}\drives.xml")
                Do While ReaderControl.Read()
                    If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Driver" Then
                        If intCountDrive >= startRecent Then
                            lbxDrivers.Items.Add(ReaderControl.ReadElementContentAsString)
                        End If
                    ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "drive_time" Then
                        If intCountDrive >= startRecent Then
                            lbxTimes.Items.Add(ReaderControl.ReadElementContentAsString)

                        End If
                        intCountDrive += 1
                    End If
                Loop
                ReaderControl.Close()
            Else

                ReaderControl = XmlReader.Create($"Cars\{cbxCurrentCar.SelectedItem}\drives.xml")
                Do While ReaderControl.Read()
                    If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "Driver" Then

                        lbxDrivers.Items.Add(ReaderControl.ReadElementContentAsString)

                    ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "drive_time" Then
                        lbxTimes.Items.Add(ReaderControl.ReadElementContentAsString)
                    End If
                Loop
                ReaderControl.Close()
            End If

            Dim intCountRefuel As Integer = 0
            ReaderControl = XmlReader.Create($"Cars\{cbxCurrentCar.SelectedItem}\refuels.xml")
            Do While ReaderControl.Read()
                If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "driver" Then
                    intCountRefuel += 1
                End If
            Loop
            ReaderControl.Close()

            Dim intCountRefuel2 As Integer = 0
            Dim boolStartAdd As Boolean = False
            Dim lstDetails(1) As String
            ReaderControl = XmlReader.Create($"Cars\{cbxCurrentCar.SelectedItem}\refuels.xml")
            Do While ReaderControl.Read()
                If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "driver" Then
                    If intCountRefuel > 10 Then
                        If intCountRefuel2 > intCountRefuel - 10 Then
                            boolStartAdd = True
                            lbxRefuelUser.Items.Add(ReaderControl.ReadElementContentAsString)
                        End If
                    Else
                        boolStartAdd = True
                        lbxRefuelUser.Items.Add(ReaderControl.ReadElementContentAsString)
                    End If
                    intCountRefuel2 += 1
                ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "refuel_price" AndAlso boolStartAdd Then
                    lstDetails(0) = ReaderControl.ReadElementContentAsString
                ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "refuel_litres" AndAlso boolStartAdd Then
                    lstDetails(1) = ReaderControl.ReadElementContentAsString
                    lbxCostLitres.Items.Add($"${lstDetails(0)}, {lstDetails(1)}L")
                End If
            Loop
            ReaderControl.Close()

            SetCalendar()

            Dim intModCheck As Integer = 1
            Dim CurSplitDate() = Date.Now.ToShortDateString().Split("/")
            Dim MonthStartDateValue As Date = $"#1/{CurSplitDate(1)}/{CurSplitDate(2)}#"
            Dim intMonthStart As Integer = MonthStartDateValue.DayOfWeek
            For Each line In CalendarCtrlDict($"rtbDay{Convert.ToInt16(CurSplitDate(0)) + intMonthStart}").Lines
                If line.Length = 1 Then
                ElseIf intModCheck Mod 2 = 1 Then
                    lbxBookingsTime.Items.Add(line)
                    intModCheck += 1
                ElseIf intModCheck Mod 2 = 0 Then
                    lbxDriverBooking.Items.Add(line)
                    intModCheck += 1
                End If
            Next

        ElseIf strCurrentForm = "Refuel" Then
            SetGenericPage(boolCancelRecursive)
            lblLitres.Visible = True
            nudLitres.Visible = True
            lblPrice.Visible = True
            nudPrice.Visible = True
            lblRefuelSummary.Visible = True
            btnSubmitRefuel.Visible = True
            lblL.Visible = True
            lblPageName.Text = "Refuel"

        ElseIf strCurrentForm = "AddDrive" Then
            SetGenericPage(boolCancelRecursive)
            lblTimeElapsed.Visible = True
            lblTimeLabel.Visible = True
            lblDriveInfoLabelTime.Visible = True
            lblDriveInfoLabelHours.Visible = True
            lblDriveInfoLabelMinutes.Visible = True
            lblDriveSummary.Visible = True
            btnStartDrive.Visible = True
            btnPauseDrive.Visible = True
            btnEndDrive.Visible = True
            cbxDriver.Visible = True
            cbxHours.Visible = True
            cbxMinutes.Visible = True
            btnSubmitManual.Visible = True
            lblPageName.Text = "Add Drive"
        ElseIf strCurrentForm = "Calendar" Then
            SetGenericPage(boolCancelRecursive)
            tlpCalendar.Visible = True
            lblMonth.Visible = True
            btnNext.Visible = True
            btnPrevious.Visible = True
            btnAddBooking.Visible = True
            SetCalendar()
            lblPageName.Text = "Calendar"
        End If
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Creates continuity by showing all common controls across various pages dashboard, refuels, calendar, enter drives
    Private Sub SetGenericPage(Optional boolCancelRecursive As Boolean = False)
        btnCalendar.Visible = True
        btnDrives.Visible = True
        btnHome.Visible = True
        btnRefuel.Visible = True
        lblPageName.Visible = True
        cbxCurrentCar.Visible = True
        btnBack.Visible = True
        Dim di As New IO.DirectoryInfo("Cars")
        Dim aryDi As IO.DirectoryInfo() = di.GetDirectories()
        Dim fdi As IO.DirectoryInfo

        For Each fdi In aryDi
            Dim DirectoryName As String = fdi.Name
            If cbxCurrentCar.Items.Contains(DirectoryName) = False Then
                cbxCurrentCar.Items.Add(DirectoryName)
            End If
        Next
        If boolCancelRecursive <> True Then
            'cbxCurrentCar.SelectedItem = strCurrentUserCarName(1)
        End If
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''updates carslist for after cars are added or destroyed
    Public Sub Refresh_lbxCars()
        lbxCars.Items.Clear()
        Dim di As New IO.DirectoryInfo("Cars")
        Dim aryDi As IO.DirectoryInfo() = di.GetDirectories()
        Dim fdi As IO.DirectoryInfo

        For Each fdi In aryDi
            Dim DirectoryName As String = fdi.Name
            lbxCars.Items.Add(DirectoryName)
        Next
        lbxCars.SelectedIndex = -1
    End Sub
    Private Sub ClearPage()
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Iterates through all control elements and makes them not visible, clears page before showing all controls for current page
        Dim Ctrl As Control = Me
        For Each ChildCtrl As Control In Ctrl.Controls
            ChildCtrl.Visible = False
        Next

    End Sub


    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''updates labe;
    Private Sub updateManualDriveSummary(intHours As Integer, intMinutes As Integer, strDriver As String)
        lblDriveSummary.Text = $"Driver: {strDriver}, Drive Length: {intHours} hours, {intMinutes} minutes."
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Calculates time between start time and current time and updates information on label
    Private Sub updateDriveTime(DriveStart As DateTime)
        Dim strText() As String = (Convert.ToString((DateTime.Now() - DriveStart))).Split(".")
        Dim strText2() As String = strText(0).Split(":")
        lblTimeElapsed.Text = $"{strText2(0)}:{strText2(1)}:{strText2(2)}"
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Uses timer object to activate update time and regular one second intervals
    Private Sub tmrTimeUpdate_Tick(sender As Object, e As EventArgs) Handles tmrTimeUpdate.Tick
        If boolDrivePause = False Then
            updateDriveTime(driveStartTime)
        End If
    End Sub


    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Updates Calendar Formatting
    Private Sub SetCalendar(Optional strDate As String = "")
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''bool month now tells program if it should highlight current day in blur
        Dim boolMonthNow = False
        Dim splitDate() = strDate.Split("/")
        Dim CurSplitDate() = Date.Now.ToShortDateString().Split("/")
        If strDate = "" Then
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''if no parameters entered as it will show current month
            strDate = Date.Now.ToShortDateString()
            boolMonthNow = True
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''If date month = current month and date year = current year then date is within current month and current day should be highlighted
        ElseIf splitDate(1) = CurSplitDate(1) And splitDate(2) = CurSplitDate(2) Then
            boolMonthNow = True
        Else
        End If
        splitDate = strDate.Split("/")
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Variable for start month
        Dim MonthStartDateValue As Date = $"#1/{splitDate(1)}/{splitDate(2)}#"
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Turns month index to text(01 to january) and month text to amount of days in given month to create a date for last day in month
        Dim MonthEndDateValue As Date = $"#{DaysInAMonth(IndexToMonth(splitDate(1)))}/{splitDate(1)}/{splitDate(2)}#"

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Finds day in week where month should begin, updates label to make it say month year 
        Dim strMonth As String = IndexToMonth(Convert.ToInt16(splitDate(1)))
        lblMonth.Text = $"{strMonth} {splitDate(2)}"
        Dim intMonthLength As Integer = DaysInAMonth(strMonth, (Convert.ToInt16(splitDate(2))))
        Dim intMonthStart As Integer = MonthStartDateValue.DayOfWeek

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Resets formatting for calendar
        For i = 1 To 42
            CalendarCtrlDict($"rtbDay{i}").BackColor = Control.DefaultBackColor
            CalendarCtrlDict($"rtbDay{i}").Text = ""
        Next

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''for days until month start it greys them out
        For i = 1 To intMonthStart
            CalendarCtrlDict($"rtbDay{i}").BackColor = Color.Gray
        Next
        Dim intCount As Integer = 1
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Finds final day and adds numbers to each day in the month
        For i = intMonthStart + 1 To intMonthStart + intMonthLength
            CalendarCtrlDict($"rtbDay{i}").Text = intCount & Environment.NewLine
            intCount += 1
        Next
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Greys days from end of month to end of calendar view
        For i = intMonthStart + intMonthLength + 1 To 42
            CalendarCtrlDict($"rtbDay{i}").BackColor = Color.Gray
        Next
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''If the month is current month it finds current day and highlights it
        If boolMonthNow Then
            CalendarCtrlDict($"rtbDay{Convert.ToInt16(CurSplitDate(0)) + intMonthStart}").BackColor = Color.LightBlue
        End If

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Complicated code but it adds booking taking into consideration recurring bookings which pass through this month
        Dim intCurrentDayPass(4) As Integer
        Dim boolAddData As Boolean = False
        Dim strBookingDetails(1) As String
        Dim ReaderControl As XmlReader
        Dim intRepeat As Integer
        Dim startDate As Date
        Dim strUser As String = ""
        ReaderControl = XmlReader.Create($"Cars\{cbxCurrentCar.SelectedItem}\calendar.xml")
        Do While ReaderControl.Read()
            If ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "recurring" Then
                intRepeat = ReaderControl.ReadElementContentAsInt
            ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "user" Then
                strUser = ReaderControl.ReadElementContentAsString

            ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "booking_date" Then
                Dim strBookingDate As String = ReaderControl.ReadElementContentAsString
                startDate = $"#{strBookingDate}#"
                Dim listStrBookingDate As String() = strBookingDate.Split("/")
                If intRepeat <> 0 Then
                    Dim intCount2 As Integer = 0
                    While startDate <= MonthEndDateValue
                        If startDate >= MonthStartDateValue Then
                            intCurrentDayPass(intCount2) = startDate.Day
                            intCount2 += 1
                            boolAddData = True
                        End If
                        startDate = startDate.AddDays(intRepeat)
                    End While
                Else
                    If listStrBookingDate(1) = splitDate(1) And listStrBookingDate(2) = splitDate(2) Then

                        intCurrentDayPass(0) = listStrBookingDate(0)
                        boolAddData = True
                    End If
                End If

            ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "booking_start_time" And boolAddData Then
                strBookingDetails(0) = ReaderControl.ReadElementContentAsString

            ElseIf ReaderControl.NodeType = XmlNodeType.Element AndAlso ReaderControl.Name = "booking_end_time" And boolAddData Then
                strBookingDetails(1) = ReaderControl.ReadElementContentAsString
                For i = 0 To 4
                    If intCurrentDayPass(i) <> 0 Then
                        CalendarCtrlDict($"rtbDay{intCurrentDayPass(i) + intMonthStart}").AppendText($"{strBookingDetails(0)} - {strBookingDetails(1)}" & Environment.NewLine)
                        CalendarCtrlDict($"rtbDay{intCurrentDayPass(i) + intMonthStart}").AppendText(strUser & Environment.NewLine)
                    End If
                Next
                For i = 0 To 4
                    intCurrentDayPass(i) = 0
                Next
                boolAddData = False
            End If
        Loop
        ReaderControl.Close()
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Calendar control structure to allow iteration through a set of controls
    Private Sub FillCalendarCtrlDict()
        With CalendarCtrlDict
            .Add("rtbDay1", rtbDay1)
            .Add("rtbDay2", rtbDay2)
            .Add("rtbDay3", rtbDay3)
            .Add("rtbDay4", rtbDay4)
            .Add("rtbDay5", rtbDay5)
            .Add("rtbDay6", rtbDay6)
            .Add("rtbDay7", rtbDay7)
            .Add("rtbDay8", rtbDay8)
            .Add("rtbDay9", rtbDay9)
            .Add("rtbDay10", rtbDay10)
            .Add("rtbDay11", rtbDay11)
            .Add("rtbDay12", rtbDay12)
            .Add("rtbDay13", rtbDay13)
            .Add("rtbDay14", rtbDay14)
            .Add("rtbDay15", rtbDay15)
            .Add("rtbDay16", rtbDay16)
            .Add("rtbDay17", rtbDay17)
            .Add("rtbDay18", rtbDay18)
            .Add("rtbDay19", rtbDay19)
            .Add("rtbDay20", rtbDay20)
            .Add("rtbDay21", rtbDay21)
            .Add("rtbDay22", rtbDay22)
            .Add("rtbDay23", rtbDay23)
            .Add("rtbDay24", rtbDay24)
            .Add("rtbDay25", rtbDay25)
            .Add("rtbDay26", rtbDay26)
            .Add("rtbDay27", rtbDay27)
            .Add("rtbDay28", rtbDay28)
            .Add("rtbDay29", rtbDay29)
            .Add("rtbDay30", rtbDay30)
            .Add("rtbDay31", rtbDay31)
            .Add("rtbDay32", rtbDay32)
            .Add("rtbDay33", rtbDay33)
            .Add("rtbDay34", rtbDay34)
            .Add("rtbDay35", rtbDay35)
            .Add("rtbDay36", rtbDay36)
            .Add("rtbDay37", rtbDay37)
            .Add("rtbDay38", rtbDay38)
            .Add("rtbDay39", rtbDay39)
            .Add("rtbDay40", rtbDay40)
            .Add("rtbDay41", rtbDay41)
            .Add("rtbDay42", rtbDay42)
        End With
    End Sub


End Class
