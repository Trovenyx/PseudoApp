﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnSignUpPage = New System.Windows.Forms.Button()
        Me.btnLoginPage = New System.Windows.Forms.Button()
        Me.btnSignUp = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtSignUpPassword2 = New System.Windows.Forms.TextBox()
        Me.txtSignUpPassword1 = New System.Windows.Forms.TextBox()
        Me.txtSignUpUsername = New System.Windows.Forms.TextBox()
        Me.lblSignUp = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblLogIn = New System.Windows.Forms.Label()
        Me.btnDeleteCar = New System.Windows.Forms.Button()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.btnAddCar = New System.Windows.Forms.Button()
        Me.btnSelectCar = New System.Windows.Forms.Button()
        Me.lbxCars = New System.Windows.Forms.ListBox()
        Me.lblCarList = New System.Windows.Forms.Label()
        Me.lblSignUpUsername = New System.Windows.Forms.Label()
        Me.lblSignUpPassword1 = New System.Windows.Forms.Label()
        Me.lblSignUpPassword2 = New System.Windows.Forms.Label()
        Me.lblSignUpName = New System.Windows.Forms.Label()
        Me.lblLogInPassword = New System.Windows.Forms.Label()
        Me.lblLogInUsername = New System.Windows.Forms.Label()
        Me.btnRefuel = New System.Windows.Forms.Button()
        Me.btnDrives = New System.Windows.Forms.Button()
        Me.btnCalendar = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.cbxCurrentCar = New System.Windows.Forms.ComboBox()
        Me.lblPageName = New System.Windows.Forms.Label()
        Me.lblTimeElapsed = New System.Windows.Forms.Label()
        Me.lblTimeLabel = New System.Windows.Forms.Label()
        Me.lblDriveSummary = New System.Windows.Forms.Label()
        Me.btnSubmitManual = New System.Windows.Forms.Button()
        Me.cbxDriver = New System.Windows.Forms.ComboBox()
        Me.cbxMinutes = New System.Windows.Forms.ComboBox()
        Me.cbxHours = New System.Windows.Forms.ComboBox()
        Me.btnPauseDrive = New System.Windows.Forms.Button()
        Me.btnEndDrive = New System.Windows.Forms.Button()
        Me.btnStartDrive = New System.Windows.Forms.Button()
        Me.lblDriveInfoLabelTime = New System.Windows.Forms.Label()
        Me.lblDriveInfoLabelHours = New System.Windows.Forms.Label()
        Me.lblDriveInfoLabelMinutes = New System.Windows.Forms.Label()
        Me.tmrTimeUpdate = New System.Windows.Forms.Timer(Me.components)
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.lblMonth = New System.Windows.Forms.Label()
        Me.btnAddBooking = New System.Windows.Forms.Button()
        Me.tlpCalendar = New System.Windows.Forms.TableLayoutPanel()
        Me.rtbDay42 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay41 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay40 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay39 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay38 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay37 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay36 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay35 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay34 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay33 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay32 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay31 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay30 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay29 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay28 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay27 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay26 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay25 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay24 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay23 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay22 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay21 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay20 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay19 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay18 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay17 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay16 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay15 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay14 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay13 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay12 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay11 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay10 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay9 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay8 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay7 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay5 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay4 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay3 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay2 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay1 = New System.Windows.Forms.RichTextBox()
        Me.rtbDay6 = New System.Windows.Forms.RichTextBox()
        Me.lblSunday = New System.Windows.Forms.Label()
        Me.lblMonday = New System.Windows.Forms.Label()
        Me.lblTuesday = New System.Windows.Forms.Label()
        Me.lblWednesday = New System.Windows.Forms.Label()
        Me.lblThursday = New System.Windows.Forms.Label()
        Me.lblFriday = New System.Windows.Forms.Label()
        Me.lblSat = New System.Windows.Forms.Label()
        Me.lbxBookingsTime = New System.Windows.Forms.ListBox()
        Me.lbxDriverBooking = New System.Windows.Forms.ListBox()
        Me.lbxCostLitres = New System.Windows.Forms.ListBox()
        Me.lbxRefuelUser = New System.Windows.Forms.ListBox()
        Me.lbxTimes = New System.Windows.Forms.ListBox()
        Me.lbxDrivers = New System.Windows.Forms.ListBox()
        Me.lblDrives = New System.Windows.Forms.Label()
        Me.lblRefuels = New System.Windows.Forms.Label()
        Me.lblTodaysBookings = New System.Windows.Forms.Label()
        Me.btnSubmitRefuel = New System.Windows.Forms.Button()
        Me.lblRefuelSummary = New System.Windows.Forms.Label()
        Me.nudLitres = New System.Windows.Forms.NumericUpDown()
        Me.nudPrice = New System.Windows.Forms.NumericUpDown()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblLitres = New System.Windows.Forms.Label()
        Me.lblL = New System.Windows.Forms.Label()
        Me.tlpCalendar.SuspendLayout()
        CType(Me.nudLitres, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSignUpPage
        '
        Me.btnSignUpPage.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignUpPage.Location = New System.Drawing.Point(89, 425)
        Me.btnSignUpPage.Name = "btnSignUpPage"
        Me.btnSignUpPage.Size = New System.Drawing.Size(288, 106)
        Me.btnSignUpPage.TabIndex = 4
        Me.btnSignUpPage.Text = "Sign Up"
        Me.btnSignUpPage.UseVisualStyleBackColor = True
        Me.btnSignUpPage.Visible = False
        '
        'btnLoginPage
        '
        Me.btnLoginPage.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoginPage.Location = New System.Drawing.Point(89, 164)
        Me.btnLoginPage.Name = "btnLoginPage"
        Me.btnLoginPage.Size = New System.Drawing.Size(288, 106)
        Me.btnLoginPage.TabIndex = 3
        Me.btnLoginPage.Text = "Log In"
        Me.btnLoginPage.UseVisualStyleBackColor = True
        Me.btnLoginPage.Visible = False
        '
        'btnSignUp
        '
        Me.btnSignUp.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSignUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignUp.Location = New System.Drawing.Point(280, 590)
        Me.btnSignUp.Name = "btnSignUp"
        Me.btnSignUp.Size = New System.Drawing.Size(165, 74)
        Me.btnSignUp.TabIndex = 16
        Me.btnSignUp.Text = "Sign Up"
        Me.btnSignUp.UseVisualStyleBackColor = False
        Me.btnSignUp.Visible = False
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(103, 466)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(264, 44)
        Me.txtName.TabIndex = 15
        Me.txtName.Visible = False
        '
        'txtSignUpPassword2
        '
        Me.txtSignUpPassword2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSignUpPassword2.Location = New System.Drawing.Point(103, 365)
        Me.txtSignUpPassword2.Name = "txtSignUpPassword2"
        Me.txtSignUpPassword2.Size = New System.Drawing.Size(264, 44)
        Me.txtSignUpPassword2.TabIndex = 14
        Me.txtSignUpPassword2.Visible = False
        '
        'txtSignUpPassword1
        '
        Me.txtSignUpPassword1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSignUpPassword1.Location = New System.Drawing.Point(103, 256)
        Me.txtSignUpPassword1.Name = "txtSignUpPassword1"
        Me.txtSignUpPassword1.Size = New System.Drawing.Size(264, 44)
        Me.txtSignUpPassword1.TabIndex = 13
        Me.txtSignUpPassword1.Visible = False
        '
        'txtSignUpUsername
        '
        Me.txtSignUpUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSignUpUsername.Location = New System.Drawing.Point(103, 158)
        Me.txtSignUpUsername.Name = "txtSignUpUsername"
        Me.txtSignUpUsername.Size = New System.Drawing.Size(264, 44)
        Me.txtSignUpUsername.TabIndex = 12
        Me.txtSignUpUsername.Visible = False
        '
        'lblSignUp
        '
        Me.lblSignUp.AutoSize = True
        Me.lblSignUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSignUp.Location = New System.Drawing.Point(171, 31)
        Me.lblSignUp.Name = "lblSignUp"
        Me.lblSignUp.Size = New System.Drawing.Size(131, 37)
        Me.lblSignUp.TabIndex = 11
        Me.lblSignUp.Text = "Sign Up"
        Me.lblSignUp.Visible = False
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(21, 17)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(71, 65)
        Me.btnBack.TabIndex = 10
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        Me.btnBack.Visible = False
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Location = New System.Drawing.Point(276, 590)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(165, 74)
        Me.btnLogin.TabIndex = 21
        Me.btnLogin.Text = "Log In"
        Me.btnLogin.UseVisualStyleBackColor = False
        Me.btnLogin.Visible = False
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(101, 398)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(264, 44)
        Me.txtPassword.TabIndex = 20
        Me.txtPassword.Visible = False
        '
        'txtUsername
        '
        Me.txtUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsername.Location = New System.Drawing.Point(101, 186)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(264, 44)
        Me.txtUsername.TabIndex = 19
        Me.txtUsername.Visible = False
        '
        'lblLogIn
        '
        Me.lblLogIn.AutoSize = True
        Me.lblLogIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogIn.Location = New System.Drawing.Point(171, 39)
        Me.lblLogIn.Name = "lblLogIn"
        Me.lblLogIn.Size = New System.Drawing.Size(106, 37)
        Me.lblLogIn.TabIndex = 18
        Me.lblLogIn.Text = "Log In"
        Me.lblLogIn.Visible = False
        '
        'btnDeleteCar
        '
        Me.btnDeleteCar.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnDeleteCar.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteCar.Location = New System.Drawing.Point(243, 361)
        Me.btnDeleteCar.Name = "btnDeleteCar"
        Me.btnDeleteCar.Size = New System.Drawing.Size(187, 104)
        Me.btnDeleteCar.TabIndex = 27
        Me.btnDeleteCar.Tag = "CarList"
        Me.btnDeleteCar.Text = "Delete"
        Me.btnDeleteCar.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.Location = New System.Drawing.Point(37, 606)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(393, 53)
        Me.btnLogOut.TabIndex = 26
        Me.btnLogOut.Tag = "CarList"
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnAddCar
        '
        Me.btnAddCar.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnAddCar.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddCar.Location = New System.Drawing.Point(37, 491)
        Me.btnAddCar.Name = "btnAddCar"
        Me.btnAddCar.Size = New System.Drawing.Size(393, 93)
        Me.btnAddCar.TabIndex = 25
        Me.btnAddCar.Tag = "CarList"
        Me.btnAddCar.Text = "Add New"
        Me.btnAddCar.UseVisualStyleBackColor = False
        '
        'btnSelectCar
        '
        Me.btnSelectCar.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSelectCar.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelectCar.Location = New System.Drawing.Point(37, 361)
        Me.btnSelectCar.Name = "btnSelectCar"
        Me.btnSelectCar.Size = New System.Drawing.Size(187, 104)
        Me.btnSelectCar.TabIndex = 24
        Me.btnSelectCar.Tag = "CarList"
        Me.btnSelectCar.Text = "Select"
        Me.btnSelectCar.UseVisualStyleBackColor = False
        '
        'lbxCars
        '
        Me.lbxCars.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbxCars.FormattingEnabled = True
        Me.lbxCars.ItemHeight = 37
        Me.lbxCars.Location = New System.Drawing.Point(37, 108)
        Me.lbxCars.Name = "lbxCars"
        Me.lbxCars.Size = New System.Drawing.Size(393, 226)
        Me.lbxCars.TabIndex = 23
        Me.lbxCars.Tag = "CarList"
        '
        'lblCarList
        '
        Me.lblCarList.AutoSize = True
        Me.lblCarList.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCarList.Location = New System.Drawing.Point(150, 35)
        Me.lblCarList.Name = "lblCarList"
        Me.lblCarList.Size = New System.Drawing.Size(128, 37)
        Me.lblCarList.TabIndex = 22
        Me.lblCarList.Tag = "CarList"
        Me.lblCarList.Text = "Car List"
        '
        'lblSignUpUsername
        '
        Me.lblSignUpUsername.AutoSize = True
        Me.lblSignUpUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSignUpUsername.Location = New System.Drawing.Point(-2, 160)
        Me.lblSignUpUsername.Name = "lblSignUpUsername"
        Me.lblSignUpUsername.Size = New System.Drawing.Size(81, 18)
        Me.lblSignUpUsername.TabIndex = 28
        Me.lblSignUpUsername.Text = "Username:"
        Me.lblSignUpUsername.Visible = False
        '
        'lblSignUpPassword1
        '
        Me.lblSignUpPassword1.AutoSize = True
        Me.lblSignUpPassword1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSignUpPassword1.Location = New System.Drawing.Point(-2, 252)
        Me.lblSignUpPassword1.Name = "lblSignUpPassword1"
        Me.lblSignUpPassword1.Size = New System.Drawing.Size(83, 18)
        Me.lblSignUpPassword1.TabIndex = 29
        Me.lblSignUpPassword1.Text = "Password: "
        Me.lblSignUpPassword1.Visible = False
        '
        'lblSignUpPassword2
        '
        Me.lblSignUpPassword2.AutoSize = True
        Me.lblSignUpPassword2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSignUpPassword2.Location = New System.Drawing.Point(-2, 344)
        Me.lblSignUpPassword2.Name = "lblSignUpPassword2"
        Me.lblSignUpPassword2.Size = New System.Drawing.Size(140, 18)
        Me.lblSignUpPassword2.TabIndex = 30
        Me.lblSignUpPassword2.Text = "Re-enter Password:"
        Me.lblSignUpPassword2.Visible = False
        '
        'lblSignUpName
        '
        Me.lblSignUpName.AutoSize = True
        Me.lblSignUpName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSignUpName.Location = New System.Drawing.Point(27, 466)
        Me.lblSignUpName.Name = "lblSignUpName"
        Me.lblSignUpName.Size = New System.Drawing.Size(52, 18)
        Me.lblSignUpName.TabIndex = 31
        Me.lblSignUpName.Text = "Name:"
        Me.lblSignUpName.Visible = False
        '
        'lblLogInPassword
        '
        Me.lblLogInPassword.AutoSize = True
        Me.lblLogInPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogInPassword.Location = New System.Drawing.Point(18, 412)
        Me.lblLogInPassword.Name = "lblLogInPassword"
        Me.lblLogInPassword.Size = New System.Drawing.Size(83, 18)
        Me.lblLogInPassword.TabIndex = 33
        Me.lblLogInPassword.Text = "Password: "
        Me.lblLogInPassword.Visible = False
        '
        'lblLogInUsername
        '
        Me.lblLogInUsername.AutoSize = True
        Me.lblLogInUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogInUsername.Location = New System.Drawing.Point(18, 203)
        Me.lblLogInUsername.Name = "lblLogInUsername"
        Me.lblLogInUsername.Size = New System.Drawing.Size(81, 18)
        Me.lblLogInUsername.TabIndex = 32
        Me.lblLogInUsername.Text = "Username:"
        Me.lblLogInUsername.Visible = False
        '
        'btnRefuel
        '
        Me.btnRefuel.Location = New System.Drawing.Point(125, 609)
        Me.btnRefuel.Name = "btnRefuel"
        Me.btnRefuel.Size = New System.Drawing.Size(73, 73)
        Me.btnRefuel.TabIndex = 41
        Me.btnRefuel.Text = "Refuel"
        Me.btnRefuel.UseVisualStyleBackColor = True
        Me.btnRefuel.Visible = False
        '
        'btnDrives
        '
        Me.btnDrives.Location = New System.Drawing.Point(253, 609)
        Me.btnDrives.Name = "btnDrives"
        Me.btnDrives.Size = New System.Drawing.Size(73, 73)
        Me.btnDrives.TabIndex = 39
        Me.btnDrives.Text = "Enter Drive"
        Me.btnDrives.UseVisualStyleBackColor = True
        Me.btnDrives.Visible = False
        '
        'btnCalendar
        '
        Me.btnCalendar.Location = New System.Drawing.Point(380, 608)
        Me.btnCalendar.Name = "btnCalendar"
        Me.btnCalendar.Size = New System.Drawing.Size(73, 73)
        Me.btnCalendar.TabIndex = 38
        Me.btnCalendar.Text = "Calendar"
        Me.btnCalendar.UseVisualStyleBackColor = True
        Me.btnCalendar.Visible = False
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(14, 608)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(73, 73)
        Me.btnHome.TabIndex = 37
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        Me.btnHome.Visible = False
        '
        'cbxCurrentCar
        '
        Me.cbxCurrentCar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxCurrentCar.FormattingEnabled = True
        Me.cbxCurrentCar.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cbxCurrentCar.Location = New System.Drawing.Point(311, 17)
        Me.cbxCurrentCar.Name = "cbxCurrentCar"
        Me.cbxCurrentCar.Size = New System.Drawing.Size(121, 21)
        Me.cbxCurrentCar.TabIndex = 36
        Me.cbxCurrentCar.Visible = False
        '
        'lblPageName
        '
        Me.lblPageName.AutoSize = True
        Me.lblPageName.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPageName.Location = New System.Drawing.Point(110, 17)
        Me.lblPageName.Name = "lblPageName"
        Me.lblPageName.Size = New System.Drawing.Size(175, 37)
        Me.lblPageName.TabIndex = 35
        Me.lblPageName.Text = "Dashboard"
        Me.lblPageName.Visible = False
        '
        'lblTimeElapsed
        '
        Me.lblTimeElapsed.AutoSize = True
        Me.lblTimeElapsed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeElapsed.Location = New System.Drawing.Point(174, 178)
        Me.lblTimeElapsed.Name = "lblTimeElapsed"
        Me.lblTimeElapsed.Size = New System.Drawing.Size(71, 20)
        Me.lblTimeElapsed.TabIndex = 52
        Me.lblTimeElapsed.Text = "00:00:00"
        Me.lblTimeElapsed.Visible = False
        '
        'lblTimeLabel
        '
        Me.lblTimeLabel.AutoSize = True
        Me.lblTimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeLabel.Location = New System.Drawing.Point(42, 171)
        Me.lblTimeLabel.Name = "lblTimeLabel"
        Me.lblTimeLabel.Size = New System.Drawing.Size(65, 36)
        Me.lblTimeLabel.TabIndex = 51
        Me.lblTimeLabel.Text = "Time" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Elapsed:"
        Me.lblTimeLabel.Visible = False
        '
        'lblDriveSummary
        '
        Me.lblDriveSummary.AutoSize = True
        Me.lblDriveSummary.Location = New System.Drawing.Point(58, 415)
        Me.lblDriveSummary.Name = "lblDriveSummary"
        Me.lblDriveSummary.Size = New System.Drawing.Size(85, 13)
        Me.lblDriveSummary.TabIndex = 50
        Me.lblDriveSummary.Text = "lblDriveSummary"
        Me.lblDriveSummary.Visible = False
        '
        'btnSubmitManual
        '
        Me.btnSubmitManual.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmitManual.Location = New System.Drawing.Point(96, 478)
        Me.btnSubmitManual.Name = "btnSubmitManual"
        Me.btnSubmitManual.Size = New System.Drawing.Size(206, 82)
        Me.btnSubmitManual.TabIndex = 48
        Me.btnSubmitManual.Text = "Submit Manual Drive"
        Me.btnSubmitManual.UseVisualStyleBackColor = True
        Me.btnSubmitManual.Visible = False
        '
        'cbxDriver
        '
        Me.cbxDriver.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxDriver.FormattingEnabled = True
        Me.cbxDriver.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cbxDriver.Location = New System.Drawing.Point(317, 458)
        Me.cbxDriver.Name = "cbxDriver"
        Me.cbxDriver.Size = New System.Drawing.Size(103, 21)
        Me.cbxDriver.TabIndex = 47
        Me.cbxDriver.Visible = False
        '
        'cbxMinutes
        '
        Me.cbxMinutes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxMinutes.DropDownWidth = 103
        Me.cbxMinutes.FormattingEnabled = True
        Me.cbxMinutes.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cbxMinutes.Location = New System.Drawing.Point(258, 329)
        Me.cbxMinutes.Name = "cbxMinutes"
        Me.cbxMinutes.Size = New System.Drawing.Size(43, 21)
        Me.cbxMinutes.TabIndex = 46
        Me.cbxMinutes.Visible = False
        '
        'cbxHours
        '
        Me.cbxHours.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxHours.DropDownWidth = 103
        Me.cbxHours.FormattingEnabled = True
        Me.cbxHours.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cbxHours.Location = New System.Drawing.Point(157, 329)
        Me.cbxHours.Name = "cbxHours"
        Me.cbxHours.Size = New System.Drawing.Size(35, 21)
        Me.cbxHours.TabIndex = 45
        Me.cbxHours.Visible = False
        '
        'btnPauseDrive
        '
        Me.btnPauseDrive.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPauseDrive.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPauseDrive.Location = New System.Drawing.Point(317, 171)
        Me.btnPauseDrive.Name = "btnPauseDrive"
        Me.btnPauseDrive.Size = New System.Drawing.Size(126, 36)
        Me.btnPauseDrive.TabIndex = 44
        Me.btnPauseDrive.Text = "Pause"
        Me.btnPauseDrive.UseVisualStyleBackColor = False
        Me.btnPauseDrive.Visible = False
        '
        'btnEndDrive
        '
        Me.btnEndDrive.BackColor = System.Drawing.Color.Red
        Me.btnEndDrive.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEndDrive.Location = New System.Drawing.Point(122, 221)
        Me.btnEndDrive.Name = "btnEndDrive"
        Me.btnEndDrive.Size = New System.Drawing.Size(180, 40)
        Me.btnEndDrive.TabIndex = 43
        Me.btnEndDrive.Text = "End Drive"
        Me.btnEndDrive.UseVisualStyleBackColor = False
        Me.btnEndDrive.Visible = False
        '
        'btnStartDrive
        '
        Me.btnStartDrive.BackColor = System.Drawing.Color.LimeGreen
        Me.btnStartDrive.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStartDrive.Location = New System.Drawing.Point(122, 119)
        Me.btnStartDrive.Name = "btnStartDrive"
        Me.btnStartDrive.Size = New System.Drawing.Size(180, 39)
        Me.btnStartDrive.TabIndex = 42
        Me.btnStartDrive.Text = "Start Drive"
        Me.btnStartDrive.UseVisualStyleBackColor = False
        Me.btnStartDrive.Visible = False
        '
        'lblDriveInfoLabelTime
        '
        Me.lblDriveInfoLabelTime.AutoSize = True
        Me.lblDriveInfoLabelTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDriveInfoLabelTime.Location = New System.Drawing.Point(104, 329)
        Me.lblDriveInfoLabelTime.Name = "lblDriveInfoLabelTime"
        Me.lblDriveInfoLabelTime.Size = New System.Drawing.Size(47, 20)
        Me.lblDriveInfoLabelTime.TabIndex = 49
        Me.lblDriveInfoLabelTime.Text = "Time:"
        Me.lblDriveInfoLabelTime.Visible = False
        '
        'lblDriveInfoLabelHours
        '
        Me.lblDriveInfoLabelHours.AutoSize = True
        Me.lblDriveInfoLabelHours.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblDriveInfoLabelHours.Location = New System.Drawing.Point(195, 330)
        Me.lblDriveInfoLabelHours.Name = "lblDriveInfoLabelHours"
        Me.lblDriveInfoLabelHours.Size = New System.Drawing.Size(57, 20)
        Me.lblDriveInfoLabelHours.TabIndex = 53
        Me.lblDriveInfoLabelHours.Text = "hours, "
        Me.lblDriveInfoLabelHours.Visible = False
        '
        'lblDriveInfoLabelMinutes
        '
        Me.lblDriveInfoLabelMinutes.AutoSize = True
        Me.lblDriveInfoLabelMinutes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblDriveInfoLabelMinutes.Location = New System.Drawing.Point(307, 330)
        Me.lblDriveInfoLabelMinutes.Name = "lblDriveInfoLabelMinutes"
        Me.lblDriveInfoLabelMinutes.Size = New System.Drawing.Size(65, 20)
        Me.lblDriveInfoLabelMinutes.TabIndex = 54
        Me.lblDriveInfoLabelMinutes.Text = "minutes"
        Me.lblDriveInfoLabelMinutes.Visible = False
        '
        'tmrTimeUpdate
        '
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(13, 94)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(66, 41)
        Me.btnPrevious.TabIndex = 60
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        Me.btnPrevious.Visible = False
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(390, 94)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(64, 41)
        Me.btnNext.TabIndex = 59
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        Me.btnNext.Visible = False
        '
        'lblMonth
        '
        Me.lblMonth.AutoSize = True
        Me.lblMonth.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonth.Location = New System.Drawing.Point(183, 100)
        Me.lblMonth.Name = "lblMonth"
        Me.lblMonth.Size = New System.Drawing.Size(66, 24)
        Me.lblMonth.TabIndex = 58
        Me.lblMonth.Text = "Label1"
        Me.lblMonth.Visible = False
        '
        'btnAddBooking
        '
        Me.btnAddBooking.Location = New System.Drawing.Point(15, 559)
        Me.btnAddBooking.Name = "btnAddBooking"
        Me.btnAddBooking.Size = New System.Drawing.Size(201, 41)
        Me.btnAddBooking.TabIndex = 57
        Me.btnAddBooking.Text = "Add Booking"
        Me.btnAddBooking.UseVisualStyleBackColor = True
        Me.btnAddBooking.Visible = False
        '
        'tlpCalendar
        '
        Me.tlpCalendar.ColumnCount = 7
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572!))
        Me.tlpCalendar.Controls.Add(Me.rtbDay42, 6, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay41, 5, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay40, 4, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay39, 3, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay38, 2, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay37, 1, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay36, 0, 6)
        Me.tlpCalendar.Controls.Add(Me.rtbDay35, 6, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay34, 5, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay33, 4, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay32, 3, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay31, 2, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay30, 1, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay29, 0, 5)
        Me.tlpCalendar.Controls.Add(Me.rtbDay28, 6, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay27, 5, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay26, 4, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay25, 3, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay24, 2, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay23, 1, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay22, 0, 4)
        Me.tlpCalendar.Controls.Add(Me.rtbDay21, 6, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay20, 5, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay19, 4, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay18, 3, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay17, 2, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay16, 1, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay15, 0, 3)
        Me.tlpCalendar.Controls.Add(Me.rtbDay14, 6, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay13, 5, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay12, 4, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay11, 3, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay10, 2, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay9, 1, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay8, 0, 2)
        Me.tlpCalendar.Controls.Add(Me.rtbDay7, 6, 1)
        Me.tlpCalendar.Controls.Add(Me.rtbDay5, 4, 1)
        Me.tlpCalendar.Controls.Add(Me.rtbDay4, 3, 1)
        Me.tlpCalendar.Controls.Add(Me.rtbDay3, 2, 1)
        Me.tlpCalendar.Controls.Add(Me.rtbDay2, 1, 1)
        Me.tlpCalendar.Controls.Add(Me.rtbDay1, 0, 1)
        Me.tlpCalendar.Controls.Add(Me.rtbDay6, 5, 1)
        Me.tlpCalendar.Controls.Add(Me.lblSunday, 0, 0)
        Me.tlpCalendar.Controls.Add(Me.lblMonday, 1, 0)
        Me.tlpCalendar.Controls.Add(Me.lblTuesday, 2, 0)
        Me.tlpCalendar.Controls.Add(Me.lblWednesday, 3, 0)
        Me.tlpCalendar.Controls.Add(Me.lblThursday, 4, 0)
        Me.tlpCalendar.Controls.Add(Me.lblFriday, 5, 0)
        Me.tlpCalendar.Controls.Add(Me.lblSat, 6, 0)
        Me.tlpCalendar.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlpCalendar.Location = New System.Drawing.Point(1, 141)
        Me.tlpCalendar.Name = "tlpCalendar"
        Me.tlpCalendar.RowCount = 7
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpCalendar.Size = New System.Drawing.Size(465, 404)
        Me.tlpCalendar.TabIndex = 55
        Me.tlpCalendar.Visible = False
        '
        'rtbDay42
        '
        Me.rtbDay42.Location = New System.Drawing.Point(399, 338)
        Me.rtbDay42.Name = "rtbDay42"
        Me.rtbDay42.ReadOnly = True
        Me.rtbDay42.Size = New System.Drawing.Size(56, 58)
        Me.rtbDay42.TabIndex = 42
        Me.rtbDay42.Text = ""
        Me.rtbDay42.WordWrap = False
        '
        'rtbDay41
        '
        Me.rtbDay41.Location = New System.Drawing.Point(333, 338)
        Me.rtbDay41.Name = "rtbDay41"
        Me.rtbDay41.ReadOnly = True
        Me.rtbDay41.Size = New System.Drawing.Size(60, 58)
        Me.rtbDay41.TabIndex = 41
        Me.rtbDay41.Text = ""
        Me.rtbDay41.WordWrap = False
        '
        'rtbDay40
        '
        Me.rtbDay40.Location = New System.Drawing.Point(267, 338)
        Me.rtbDay40.Name = "rtbDay40"
        Me.rtbDay40.ReadOnly = True
        Me.rtbDay40.Size = New System.Drawing.Size(56, 58)
        Me.rtbDay40.TabIndex = 40
        Me.rtbDay40.Text = ""
        Me.rtbDay40.WordWrap = False
        '
        'rtbDay39
        '
        Me.rtbDay39.Location = New System.Drawing.Point(201, 338)
        Me.rtbDay39.Name = "rtbDay39"
        Me.rtbDay39.ReadOnly = True
        Me.rtbDay39.Size = New System.Drawing.Size(56, 58)
        Me.rtbDay39.TabIndex = 39
        Me.rtbDay39.Text = ""
        Me.rtbDay39.WordWrap = False
        '
        'rtbDay38
        '
        Me.rtbDay38.Location = New System.Drawing.Point(135, 338)
        Me.rtbDay38.Name = "rtbDay38"
        Me.rtbDay38.ReadOnly = True
        Me.rtbDay38.Size = New System.Drawing.Size(56, 58)
        Me.rtbDay38.TabIndex = 38
        Me.rtbDay38.Text = ""
        Me.rtbDay38.WordWrap = False
        '
        'rtbDay37
        '
        Me.rtbDay37.Location = New System.Drawing.Point(69, 338)
        Me.rtbDay37.Name = "rtbDay37"
        Me.rtbDay37.ReadOnly = True
        Me.rtbDay37.Size = New System.Drawing.Size(56, 58)
        Me.rtbDay37.TabIndex = 37
        Me.rtbDay37.Text = ""
        Me.rtbDay37.WordWrap = False
        '
        'rtbDay36
        '
        Me.rtbDay36.Location = New System.Drawing.Point(3, 338)
        Me.rtbDay36.Name = "rtbDay36"
        Me.rtbDay36.ReadOnly = True
        Me.rtbDay36.Size = New System.Drawing.Size(56, 58)
        Me.rtbDay36.TabIndex = 36
        Me.rtbDay36.Text = ""
        Me.rtbDay36.WordWrap = False
        '
        'rtbDay35
        '
        Me.rtbDay35.Location = New System.Drawing.Point(399, 275)
        Me.rtbDay35.Name = "rtbDay35"
        Me.rtbDay35.ReadOnly = True
        Me.rtbDay35.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay35.TabIndex = 35
        Me.rtbDay35.Text = ""
        Me.rtbDay35.WordWrap = False
        '
        'rtbDay34
        '
        Me.rtbDay34.Location = New System.Drawing.Point(333, 275)
        Me.rtbDay34.Name = "rtbDay34"
        Me.rtbDay34.ReadOnly = True
        Me.rtbDay34.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay34.TabIndex = 34
        Me.rtbDay34.Text = ""
        Me.rtbDay34.WordWrap = False
        '
        'rtbDay33
        '
        Me.rtbDay33.Location = New System.Drawing.Point(267, 275)
        Me.rtbDay33.Name = "rtbDay33"
        Me.rtbDay33.ReadOnly = True
        Me.rtbDay33.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay33.TabIndex = 33
        Me.rtbDay33.Text = ""
        Me.rtbDay33.WordWrap = False
        '
        'rtbDay32
        '
        Me.rtbDay32.Location = New System.Drawing.Point(201, 275)
        Me.rtbDay32.Name = "rtbDay32"
        Me.rtbDay32.ReadOnly = True
        Me.rtbDay32.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay32.TabIndex = 32
        Me.rtbDay32.Text = ""
        Me.rtbDay32.WordWrap = False
        '
        'rtbDay31
        '
        Me.rtbDay31.Location = New System.Drawing.Point(135, 275)
        Me.rtbDay31.Name = "rtbDay31"
        Me.rtbDay31.ReadOnly = True
        Me.rtbDay31.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay31.TabIndex = 31
        Me.rtbDay31.Text = ""
        Me.rtbDay31.WordWrap = False
        '
        'rtbDay30
        '
        Me.rtbDay30.Location = New System.Drawing.Point(69, 275)
        Me.rtbDay30.Name = "rtbDay30"
        Me.rtbDay30.ReadOnly = True
        Me.rtbDay30.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay30.TabIndex = 30
        Me.rtbDay30.Text = ""
        Me.rtbDay30.WordWrap = False
        '
        'rtbDay29
        '
        Me.rtbDay29.Location = New System.Drawing.Point(3, 275)
        Me.rtbDay29.Name = "rtbDay29"
        Me.rtbDay29.ReadOnly = True
        Me.rtbDay29.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay29.TabIndex = 29
        Me.rtbDay29.Text = ""
        Me.rtbDay29.WordWrap = False
        '
        'rtbDay28
        '
        Me.rtbDay28.Location = New System.Drawing.Point(399, 212)
        Me.rtbDay28.Name = "rtbDay28"
        Me.rtbDay28.ReadOnly = True
        Me.rtbDay28.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay28.TabIndex = 28
        Me.rtbDay28.Text = ""
        Me.rtbDay28.WordWrap = False
        '
        'rtbDay27
        '
        Me.rtbDay27.Location = New System.Drawing.Point(333, 212)
        Me.rtbDay27.Name = "rtbDay27"
        Me.rtbDay27.ReadOnly = True
        Me.rtbDay27.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay27.TabIndex = 27
        Me.rtbDay27.Text = ""
        Me.rtbDay27.WordWrap = False
        '
        'rtbDay26
        '
        Me.rtbDay26.Location = New System.Drawing.Point(267, 212)
        Me.rtbDay26.Name = "rtbDay26"
        Me.rtbDay26.ReadOnly = True
        Me.rtbDay26.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay26.TabIndex = 26
        Me.rtbDay26.Text = ""
        Me.rtbDay26.WordWrap = False
        '
        'rtbDay25
        '
        Me.rtbDay25.Location = New System.Drawing.Point(201, 212)
        Me.rtbDay25.Name = "rtbDay25"
        Me.rtbDay25.ReadOnly = True
        Me.rtbDay25.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay25.TabIndex = 25
        Me.rtbDay25.Text = ""
        Me.rtbDay25.WordWrap = False
        '
        'rtbDay24
        '
        Me.rtbDay24.Location = New System.Drawing.Point(135, 212)
        Me.rtbDay24.Name = "rtbDay24"
        Me.rtbDay24.ReadOnly = True
        Me.rtbDay24.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay24.TabIndex = 24
        Me.rtbDay24.Text = ""
        Me.rtbDay24.WordWrap = False
        '
        'rtbDay23
        '
        Me.rtbDay23.Location = New System.Drawing.Point(69, 212)
        Me.rtbDay23.Name = "rtbDay23"
        Me.rtbDay23.ReadOnly = True
        Me.rtbDay23.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay23.TabIndex = 23
        Me.rtbDay23.Text = ""
        Me.rtbDay23.WordWrap = False
        '
        'rtbDay22
        '
        Me.rtbDay22.Location = New System.Drawing.Point(3, 212)
        Me.rtbDay22.Name = "rtbDay22"
        Me.rtbDay22.ReadOnly = True
        Me.rtbDay22.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay22.TabIndex = 22
        Me.rtbDay22.Text = ""
        Me.rtbDay22.WordWrap = False
        '
        'rtbDay21
        '
        Me.rtbDay21.Location = New System.Drawing.Point(399, 149)
        Me.rtbDay21.Name = "rtbDay21"
        Me.rtbDay21.ReadOnly = True
        Me.rtbDay21.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay21.TabIndex = 21
        Me.rtbDay21.Text = ""
        Me.rtbDay21.WordWrap = False
        '
        'rtbDay20
        '
        Me.rtbDay20.Location = New System.Drawing.Point(333, 149)
        Me.rtbDay20.Name = "rtbDay20"
        Me.rtbDay20.ReadOnly = True
        Me.rtbDay20.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay20.TabIndex = 20
        Me.rtbDay20.Text = ""
        Me.rtbDay20.WordWrap = False
        '
        'rtbDay19
        '
        Me.rtbDay19.Location = New System.Drawing.Point(267, 149)
        Me.rtbDay19.Name = "rtbDay19"
        Me.rtbDay19.ReadOnly = True
        Me.rtbDay19.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay19.TabIndex = 19
        Me.rtbDay19.Text = ""
        Me.rtbDay19.WordWrap = False
        '
        'rtbDay18
        '
        Me.rtbDay18.Location = New System.Drawing.Point(201, 149)
        Me.rtbDay18.Name = "rtbDay18"
        Me.rtbDay18.ReadOnly = True
        Me.rtbDay18.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay18.TabIndex = 18
        Me.rtbDay18.Text = ""
        Me.rtbDay18.WordWrap = False
        '
        'rtbDay17
        '
        Me.rtbDay17.Location = New System.Drawing.Point(135, 149)
        Me.rtbDay17.Name = "rtbDay17"
        Me.rtbDay17.ReadOnly = True
        Me.rtbDay17.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay17.TabIndex = 17
        Me.rtbDay17.Text = ""
        Me.rtbDay17.WordWrap = False
        '
        'rtbDay16
        '
        Me.rtbDay16.Location = New System.Drawing.Point(69, 149)
        Me.rtbDay16.Name = "rtbDay16"
        Me.rtbDay16.ReadOnly = True
        Me.rtbDay16.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay16.TabIndex = 16
        Me.rtbDay16.Text = ""
        Me.rtbDay16.WordWrap = False
        '
        'rtbDay15
        '
        Me.rtbDay15.Location = New System.Drawing.Point(3, 149)
        Me.rtbDay15.Name = "rtbDay15"
        Me.rtbDay15.ReadOnly = True
        Me.rtbDay15.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay15.TabIndex = 15
        Me.rtbDay15.Text = ""
        Me.rtbDay15.WordWrap = False
        '
        'rtbDay14
        '
        Me.rtbDay14.Location = New System.Drawing.Point(399, 86)
        Me.rtbDay14.Name = "rtbDay14"
        Me.rtbDay14.ReadOnly = True
        Me.rtbDay14.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay14.TabIndex = 14
        Me.rtbDay14.Text = ""
        Me.rtbDay14.WordWrap = False
        '
        'rtbDay13
        '
        Me.rtbDay13.Location = New System.Drawing.Point(333, 86)
        Me.rtbDay13.Name = "rtbDay13"
        Me.rtbDay13.ReadOnly = True
        Me.rtbDay13.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay13.TabIndex = 13
        Me.rtbDay13.Text = ""
        Me.rtbDay13.WordWrap = False
        '
        'rtbDay12
        '
        Me.rtbDay12.Location = New System.Drawing.Point(267, 86)
        Me.rtbDay12.Name = "rtbDay12"
        Me.rtbDay12.ReadOnly = True
        Me.rtbDay12.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay12.TabIndex = 12
        Me.rtbDay12.Text = ""
        Me.rtbDay12.WordWrap = False
        '
        'rtbDay11
        '
        Me.rtbDay11.Location = New System.Drawing.Point(201, 86)
        Me.rtbDay11.Name = "rtbDay11"
        Me.rtbDay11.ReadOnly = True
        Me.rtbDay11.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay11.TabIndex = 11
        Me.rtbDay11.Text = ""
        Me.rtbDay11.WordWrap = False
        '
        'rtbDay10
        '
        Me.rtbDay10.Location = New System.Drawing.Point(135, 86)
        Me.rtbDay10.Name = "rtbDay10"
        Me.rtbDay10.ReadOnly = True
        Me.rtbDay10.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay10.TabIndex = 10
        Me.rtbDay10.Text = ""
        Me.rtbDay10.WordWrap = False
        '
        'rtbDay9
        '
        Me.rtbDay9.Location = New System.Drawing.Point(69, 86)
        Me.rtbDay9.Name = "rtbDay9"
        Me.rtbDay9.ReadOnly = True
        Me.rtbDay9.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay9.TabIndex = 9
        Me.rtbDay9.Text = ""
        Me.rtbDay9.WordWrap = False
        '
        'rtbDay8
        '
        Me.rtbDay8.Location = New System.Drawing.Point(3, 86)
        Me.rtbDay8.Name = "rtbDay8"
        Me.rtbDay8.ReadOnly = True
        Me.rtbDay8.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay8.TabIndex = 8
        Me.rtbDay8.Text = ""
        Me.rtbDay8.WordWrap = False
        '
        'rtbDay7
        '
        Me.rtbDay7.Location = New System.Drawing.Point(399, 23)
        Me.rtbDay7.Name = "rtbDay7"
        Me.rtbDay7.ReadOnly = True
        Me.rtbDay7.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay7.TabIndex = 7
        Me.rtbDay7.Text = ""
        Me.rtbDay7.WordWrap = False
        '
        'rtbDay5
        '
        Me.rtbDay5.Location = New System.Drawing.Point(267, 23)
        Me.rtbDay5.Name = "rtbDay5"
        Me.rtbDay5.ReadOnly = True
        Me.rtbDay5.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay5.TabIndex = 6
        Me.rtbDay5.Text = ""
        Me.rtbDay5.WordWrap = False
        '
        'rtbDay4
        '
        Me.rtbDay4.Location = New System.Drawing.Point(201, 23)
        Me.rtbDay4.Name = "rtbDay4"
        Me.rtbDay4.ReadOnly = True
        Me.rtbDay4.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay4.TabIndex = 5
        Me.rtbDay4.Text = ""
        Me.rtbDay4.WordWrap = False
        '
        'rtbDay3
        '
        Me.rtbDay3.Location = New System.Drawing.Point(135, 23)
        Me.rtbDay3.Name = "rtbDay3"
        Me.rtbDay3.ReadOnly = True
        Me.rtbDay3.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay3.TabIndex = 3
        Me.rtbDay3.Text = ""
        Me.rtbDay3.WordWrap = False
        '
        'rtbDay2
        '
        Me.rtbDay2.Location = New System.Drawing.Point(69, 23)
        Me.rtbDay2.Name = "rtbDay2"
        Me.rtbDay2.ReadOnly = True
        Me.rtbDay2.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay2.TabIndex = 2
        Me.rtbDay2.Text = ""
        Me.rtbDay2.WordWrap = False
        '
        'rtbDay1
        '
        Me.rtbDay1.Location = New System.Drawing.Point(3, 23)
        Me.rtbDay1.Name = "rtbDay1"
        Me.rtbDay1.ReadOnly = True
        Me.rtbDay1.Size = New System.Drawing.Size(56, 57)
        Me.rtbDay1.TabIndex = 1
        Me.rtbDay1.Text = ""
        Me.rtbDay1.WordWrap = False
        '
        'rtbDay6
        '
        Me.rtbDay6.BackColor = System.Drawing.SystemColors.Control
        Me.rtbDay6.Location = New System.Drawing.Point(333, 23)
        Me.rtbDay6.Name = "rtbDay6"
        Me.rtbDay6.ReadOnly = True
        Me.rtbDay6.Size = New System.Drawing.Size(57, 57)
        Me.rtbDay6.TabIndex = 0
        Me.rtbDay6.Text = ""
        Me.rtbDay6.WordWrap = False
        '
        'lblSunday
        '
        Me.lblSunday.AutoSize = True
        Me.lblSunday.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSunday.Location = New System.Drawing.Point(3, 0)
        Me.lblSunday.Name = "lblSunday"
        Me.lblSunday.Size = New System.Drawing.Size(29, 15)
        Me.lblSunday.TabIndex = 43
        Me.lblSunday.Text = "Sun"
        '
        'lblMonday
        '
        Me.lblMonday.AutoSize = True
        Me.lblMonday.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonday.Location = New System.Drawing.Point(69, 0)
        Me.lblMonday.Name = "lblMonday"
        Me.lblMonday.Size = New System.Drawing.Size(32, 15)
        Me.lblMonday.TabIndex = 44
        Me.lblMonday.Text = "Mon"
        '
        'lblTuesday
        '
        Me.lblTuesday.AutoSize = True
        Me.lblTuesday.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTuesday.Location = New System.Drawing.Point(135, 0)
        Me.lblTuesday.Name = "lblTuesday"
        Me.lblTuesday.Size = New System.Drawing.Size(34, 15)
        Me.lblTuesday.TabIndex = 45
        Me.lblTuesday.Text = "Tues"
        '
        'lblWednesday
        '
        Me.lblWednesday.AutoSize = True
        Me.lblWednesday.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWednesday.Location = New System.Drawing.Point(201, 0)
        Me.lblWednesday.Name = "lblWednesday"
        Me.lblWednesday.Size = New System.Drawing.Size(30, 13)
        Me.lblWednesday.TabIndex = 46
        Me.lblWednesday.Text = "Wed"
        '
        'lblThursday
        '
        Me.lblThursday.AutoSize = True
        Me.lblThursday.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThursday.Location = New System.Drawing.Point(267, 0)
        Me.lblThursday.Name = "lblThursday"
        Me.lblThursday.Size = New System.Drawing.Size(34, 13)
        Me.lblThursday.TabIndex = 47
        Me.lblThursday.Text = "Thurs"
        '
        'lblFriday
        '
        Me.lblFriday.AutoSize = True
        Me.lblFriday.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFriday.Location = New System.Drawing.Point(333, 0)
        Me.lblFriday.Name = "lblFriday"
        Me.lblFriday.Size = New System.Drawing.Size(18, 13)
        Me.lblFriday.TabIndex = 48
        Me.lblFriday.Text = "Fri"
        '
        'lblSat
        '
        Me.lblSat.AutoSize = True
        Me.lblSat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSat.Location = New System.Drawing.Point(399, 0)
        Me.lblSat.Name = "lblSat"
        Me.lblSat.Size = New System.Drawing.Size(23, 13)
        Me.lblSat.TabIndex = 49
        Me.lblSat.Text = "Sat"
        '
        'lbxBookingsTime
        '
        Me.lbxBookingsTime.Enabled = False
        Me.lbxBookingsTime.FormattingEnabled = True
        Me.lbxBookingsTime.Location = New System.Drawing.Point(345, 467)
        Me.lbxBookingsTime.Name = "lbxBookingsTime"
        Me.lbxBookingsTime.Size = New System.Drawing.Size(104, 121)
        Me.lbxBookingsTime.TabIndex = 66
        Me.lbxBookingsTime.Visible = False
        '
        'lbxDriverBooking
        '
        Me.lbxDriverBooking.Enabled = False
        Me.lbxDriverBooking.FormattingEnabled = True
        Me.lbxDriverBooking.Location = New System.Drawing.Point(246, 467)
        Me.lbxDriverBooking.Name = "lbxDriverBooking"
        Me.lbxDriverBooking.Size = New System.Drawing.Size(100, 121)
        Me.lbxDriverBooking.TabIndex = 65
        Me.lbxDriverBooking.Visible = False
        '
        'lbxCostLitres
        '
        Me.lbxCostLitres.Enabled = False
        Me.lbxCostLitres.FormattingEnabled = True
        Me.lbxCostLitres.Location = New System.Drawing.Point(345, 108)
        Me.lbxCostLitres.Name = "lbxCostLitres"
        Me.lbxCostLitres.Size = New System.Drawing.Size(104, 316)
        Me.lbxCostLitres.TabIndex = 64
        Me.lbxCostLitres.Visible = False
        '
        'lbxRefuelUser
        '
        Me.lbxRefuelUser.Enabled = False
        Me.lbxRefuelUser.FormattingEnabled = True
        Me.lbxRefuelUser.Location = New System.Drawing.Point(246, 108)
        Me.lbxRefuelUser.Name = "lbxRefuelUser"
        Me.lbxRefuelUser.Size = New System.Drawing.Size(100, 316)
        Me.lbxRefuelUser.TabIndex = 63
        Me.lbxRefuelUser.Visible = False
        '
        'lbxTimes
        '
        Me.lbxTimes.Enabled = False
        Me.lbxTimes.FormattingEnabled = True
        Me.lbxTimes.Location = New System.Drawing.Point(125, 107)
        Me.lbxTimes.Name = "lbxTimes"
        Me.lbxTimes.Size = New System.Drawing.Size(94, 316)
        Me.lbxTimes.TabIndex = 62
        Me.lbxTimes.Visible = False
        '
        'lbxDrivers
        '
        Me.lbxDrivers.Enabled = False
        Me.lbxDrivers.FormattingEnabled = True
        Me.lbxDrivers.Location = New System.Drawing.Point(17, 107)
        Me.lbxDrivers.Name = "lbxDrivers"
        Me.lbxDrivers.Size = New System.Drawing.Size(109, 316)
        Me.lbxDrivers.TabIndex = 61
        Me.lbxDrivers.Visible = False
        '
        'lblDrives
        '
        Me.lblDrives.AutoSize = True
        Me.lblDrives.Location = New System.Drawing.Point(85, 91)
        Me.lblDrives.Name = "lblDrives"
        Me.lblDrives.Size = New System.Drawing.Size(75, 13)
        Me.lblDrives.TabIndex = 67
        Me.lblDrives.Text = "Recent Drives"
        Me.lblDrives.Visible = False
        '
        'lblRefuels
        '
        Me.lblRefuels.AutoSize = True
        Me.lblRefuels.Location = New System.Drawing.Point(302, 91)
        Me.lblRefuels.Name = "lblRefuels"
        Me.lblRefuels.Size = New System.Drawing.Size(81, 13)
        Me.lblRefuels.TabIndex = 68
        Me.lblRefuels.Text = "Recent Refuels"
        Me.lblRefuels.Visible = False
        '
        'lblTodaysBookings
        '
        Me.lblTodaysBookings.AutoSize = True
        Me.lblTodaysBookings.Location = New System.Drawing.Point(313, 450)
        Me.lblTodaysBookings.Name = "lblTodaysBookings"
        Me.lblTodaysBookings.Size = New System.Drawing.Size(89, 13)
        Me.lblTodaysBookings.TabIndex = 71
        Me.lblTodaysBookings.Text = "Todays Bookings"
        Me.lblTodaysBookings.Visible = False
        '
        'btnSubmitRefuel
        '
        Me.btnSubmitRefuel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmitRefuel.Location = New System.Drawing.Point(257, 479)
        Me.btnSubmitRefuel.Name = "btnSubmitRefuel"
        Me.btnSubmitRefuel.Size = New System.Drawing.Size(178, 70)
        Me.btnSubmitRefuel.TabIndex = 77
        Me.btnSubmitRefuel.Text = "Submit Refuel"
        Me.btnSubmitRefuel.UseVisualStyleBackColor = True
        Me.btnSubmitRefuel.Visible = False
        '
        'lblRefuelSummary
        '
        Me.lblRefuelSummary.AutoSize = True
        Me.lblRefuelSummary.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRefuelSummary.Location = New System.Drawing.Point(52, 419)
        Me.lblRefuelSummary.Name = "lblRefuelSummary"
        Me.lblRefuelSummary.Size = New System.Drawing.Size(321, 25)
        Me.lblRefuelSummary.TabIndex = 76
        Me.lblRefuelSummary.Text = "Refueled 0L for $0 at $0 per litre"
        Me.lblRefuelSummary.Visible = False
        '
        'nudLitres
        '
        Me.nudLitres.DecimalPlaces = 2
        Me.nudLitres.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudLitres.Location = New System.Drawing.Point(206, 146)
        Me.nudLitres.Maximum = New Decimal(New Integer() {200, 0, 0, 0})
        Me.nudLitres.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudLitres.Name = "nudLitres"
        Me.nudLitres.Size = New System.Drawing.Size(61, 29)
        Me.nudLitres.TabIndex = 75
        Me.nudLitres.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudLitres.Visible = False
        '
        'nudPrice
        '
        Me.nudPrice.DecimalPlaces = 2
        Me.nudPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudPrice.Location = New System.Drawing.Point(226, 285)
        Me.nudPrice.Maximum = New Decimal(New Integer() {200, 0, 0, 0})
        Me.nudPrice.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPrice.Name = "nudPrice"
        Me.nudPrice.Size = New System.Drawing.Size(59, 29)
        Me.nudPrice.TabIndex = 74
        Me.nudPrice.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPrice.Visible = False
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice.Location = New System.Drawing.Point(31, 285)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(189, 25)
        Me.lblPrice.TabIndex = 73
        Me.lblPrice.Text = "Price of Refuel:   $"
        Me.lblPrice.Visible = False
        '
        'lblLitres
        '
        Me.lblLitres.AutoSize = True
        Me.lblLitres.BackColor = System.Drawing.Color.Transparent
        Me.lblLitres.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLitres.Location = New System.Drawing.Point(31, 146)
        Me.lblLitres.Name = "lblLitres"
        Me.lblLitres.Size = New System.Drawing.Size(163, 25)
        Me.lblLitres.TabIndex = 72
        Me.lblLitres.Text = "Litres Refueled:"
        Me.lblLitres.Visible = False
        '
        'lblL
        '
        Me.lblL.AutoSize = True
        Me.lblL.BackColor = System.Drawing.Color.Transparent
        Me.lblL.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblL.Location = New System.Drawing.Point(273, 148)
        Me.lblL.Name = "lblL"
        Me.lblL.Size = New System.Drawing.Size(24, 25)
        Me.lblL.TabIndex = 78
        Me.lblL.Text = "L"
        Me.lblL.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(467, 694)
        Me.Controls.Add(Me.lbxCostLitres)
        Me.Controls.Add(Me.lbxRefuelUser)
        Me.Controls.Add(Me.lbxTimes)
        Me.Controls.Add(Me.lbxDrivers)
        Me.Controls.Add(Me.lblMonth)
        Me.Controls.Add(Me.lblL)
        Me.Controls.Add(Me.btnSubmitRefuel)
        Me.Controls.Add(Me.lblRefuelSummary)
        Me.Controls.Add(Me.nudLitres)
        Me.Controls.Add(Me.nudPrice)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblLitres)
        Me.Controls.Add(Me.lblTodaysBookings)
        Me.Controls.Add(Me.lblRefuels)
        Me.Controls.Add(Me.lblDrives)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.lblDriveInfoLabelMinutes)
        Me.Controls.Add(Me.lblDriveInfoLabelHours)
        Me.Controls.Add(Me.lblTimeElapsed)
        Me.Controls.Add(Me.lblTimeLabel)
        Me.Controls.Add(Me.lblDriveSummary)
        Me.Controls.Add(Me.btnSubmitManual)
        Me.Controls.Add(Me.cbxDriver)
        Me.Controls.Add(Me.cbxMinutes)
        Me.Controls.Add(Me.cbxHours)
        Me.Controls.Add(Me.btnPauseDrive)
        Me.Controls.Add(Me.btnEndDrive)
        Me.Controls.Add(Me.btnStartDrive)
        Me.Controls.Add(Me.lblDriveInfoLabelTime)
        Me.Controls.Add(Me.btnRefuel)
        Me.Controls.Add(Me.btnDrives)
        Me.Controls.Add(Me.btnCalendar)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.cbxCurrentCar)
        Me.Controls.Add(Me.lblPageName)
        Me.Controls.Add(Me.lblLogInPassword)
        Me.Controls.Add(Me.lblLogInUsername)
        Me.Controls.Add(Me.lblSignUpName)
        Me.Controls.Add(Me.lblSignUpPassword2)
        Me.Controls.Add(Me.lblSignUpPassword1)
        Me.Controls.Add(Me.lblSignUpUsername)
        Me.Controls.Add(Me.lblCarList)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.lblLogIn)
        Me.Controls.Add(Me.btnSignUp)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtSignUpPassword2)
        Me.Controls.Add(Me.txtSignUpPassword1)
        Me.Controls.Add(Me.txtSignUpUsername)
        Me.Controls.Add(Me.lblSignUp)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnSignUpPage)
        Me.Controls.Add(Me.btnLoginPage)
        Me.Controls.Add(Me.btnDeleteCar)
        Me.Controls.Add(Me.btnSelectCar)
        Me.Controls.Add(Me.lbxCars)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnAddCar)
        Me.Controls.Add(Me.lbxBookingsTime)
        Me.Controls.Add(Me.lbxDriverBooking)
        Me.Controls.Add(Me.tlpCalendar)
        Me.Controls.Add(Me.btnAddBooking)
        Me.Name = "Form1"
        Me.Text = "Car Management App"
        Me.tlpCalendar.ResumeLayout(False)
        Me.tlpCalendar.PerformLayout()
        CType(Me.nudLitres, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPrice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSignUpPage As Button
    Friend WithEvents btnLoginPage As Button
    Friend WithEvents btnSignUp As Button
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtSignUpPassword2 As TextBox
    Friend WithEvents txtSignUpPassword1 As TextBox
    Friend WithEvents txtSignUpUsername As TextBox
    Friend WithEvents lblSignUp As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents btnLogin As Button
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblLogIn As Label
    Friend WithEvents btnDeleteCar As Button
    Friend WithEvents btnLogOut As Button
    Friend WithEvents btnAddCar As Button
    Friend WithEvents btnSelectCar As Button
    Friend WithEvents lbxCars As ListBox
    Friend WithEvents lblCarList As Label
    Friend WithEvents lblSignUpUsername As Label
    Friend WithEvents lblSignUpPassword1 As Label
    Friend WithEvents lblSignUpPassword2 As Label
    Friend WithEvents lblSignUpName As Label
    Friend WithEvents lblLogInPassword As Label
    Friend WithEvents lblLogInUsername As Label
    Friend WithEvents btnRefuel As Button
    Friend WithEvents btnDrives As Button
    Friend WithEvents btnCalendar As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents cbxCurrentCar As ComboBox
    Friend WithEvents lblPageName As Label
    Friend WithEvents lblTimeElapsed As Label
    Friend WithEvents lblTimeLabel As Label
    Friend WithEvents lblDriveSummary As Label
    Friend WithEvents btnSubmitManual As Button
    Friend WithEvents cbxDriver As ComboBox
    Friend WithEvents cbxMinutes As ComboBox
    Friend WithEvents cbxHours As ComboBox
    Friend WithEvents btnPauseDrive As Button
    Friend WithEvents btnEndDrive As Button
    Friend WithEvents btnStartDrive As Button
    Friend WithEvents lblDriveInfoLabelTime As Label
    Friend WithEvents lblDriveInfoLabelHours As Label
    Friend WithEvents lblDriveInfoLabelMinutes As Label
    Friend WithEvents tmrTimeUpdate As Timer
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents lblMonth As Label
    Friend WithEvents btnAddBooking As Button
    Friend WithEvents tlpCalendar As TableLayoutPanel
    Friend WithEvents rtbDay42 As RichTextBox
    Friend WithEvents rtbDay41 As RichTextBox
    Friend WithEvents rtbDay40 As RichTextBox
    Friend WithEvents rtbDay39 As RichTextBox
    Friend WithEvents rtbDay38 As RichTextBox
    Friend WithEvents rtbDay37 As RichTextBox
    Friend WithEvents rtbDay36 As RichTextBox
    Friend WithEvents rtbDay35 As RichTextBox
    Friend WithEvents rtbDay34 As RichTextBox
    Friend WithEvents rtbDay33 As RichTextBox
    Friend WithEvents rtbDay32 As RichTextBox
    Friend WithEvents rtbDay31 As RichTextBox
    Friend WithEvents rtbDay30 As RichTextBox
    Friend WithEvents rtbDay29 As RichTextBox
    Friend WithEvents rtbDay28 As RichTextBox
    Friend WithEvents rtbDay27 As RichTextBox
    Friend WithEvents rtbDay26 As RichTextBox
    Friend WithEvents rtbDay25 As RichTextBox
    Friend WithEvents rtbDay24 As RichTextBox
    Friend WithEvents rtbDay23 As RichTextBox
    Friend WithEvents rtbDay22 As RichTextBox
    Friend WithEvents rtbDay21 As RichTextBox
    Friend WithEvents rtbDay20 As RichTextBox
    Friend WithEvents rtbDay19 As RichTextBox
    Friend WithEvents rtbDay18 As RichTextBox
    Friend WithEvents rtbDay17 As RichTextBox
    Friend WithEvents rtbDay16 As RichTextBox
    Friend WithEvents rtbDay15 As RichTextBox
    Friend WithEvents rtbDay14 As RichTextBox
    Friend WithEvents rtbDay13 As RichTextBox
    Friend WithEvents rtbDay12 As RichTextBox
    Friend WithEvents rtbDay11 As RichTextBox
    Friend WithEvents rtbDay10 As RichTextBox
    Friend WithEvents rtbDay9 As RichTextBox
    Friend WithEvents rtbDay8 As RichTextBox
    Friend WithEvents rtbDay7 As RichTextBox
    Friend WithEvents rtbDay5 As RichTextBox
    Friend WithEvents rtbDay4 As RichTextBox
    Friend WithEvents rtbDay3 As RichTextBox
    Friend WithEvents rtbDay2 As RichTextBox
    Friend WithEvents rtbDay1 As RichTextBox
    Friend WithEvents rtbDay6 As RichTextBox
    Friend WithEvents lbxBookingsTime As ListBox
    Friend WithEvents lbxDriverBooking As ListBox
    Friend WithEvents lbxCostLitres As ListBox
    Friend WithEvents lbxRefuelUser As ListBox
    Friend WithEvents lbxTimes As ListBox
    Friend WithEvents lbxDrivers As ListBox
    Friend WithEvents lblDrives As Label
    Friend WithEvents lblRefuels As Label
    Friend WithEvents lblTodaysBookings As Label
    Friend WithEvents btnSubmitRefuel As Button
    Friend WithEvents lblRefuelSummary As Label
    Friend WithEvents nudLitres As NumericUpDown
    Friend WithEvents nudPrice As NumericUpDown
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblLitres As Label
    Friend WithEvents lblL As Label
    Friend WithEvents lblSunday As Label
    Friend WithEvents lblTuesday As Label
    Friend WithEvents lblMonday As Label
    Friend WithEvents lblSat As Label
    Friend WithEvents lblFriday As Label
    Friend WithEvents lblThursday As Label
    Friend WithEvents lblWednesday As Label
End Class
