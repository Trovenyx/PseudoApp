﻿Imports System.Xml

Public Module SATFunctions
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Text Validation
    Function ValidateText(inputText As String, inputInformation As String, excludedCharacters As String, minLength As Integer, maxLength As Integer) As String
        If inputText = "" Then
            Return $"{inputInformation} field is empty, please enter {inputInformation}"
        ElseIf inputText.Length < minLength Then
            Return $"{inputInformation} must be at least {minLength} characters long"
        ElseIf inputText.Length > maxLength Then
            Return $"{inputInformation} must be no more than {maxLength} characters long"
        End If
        For Each x In inputText
            If excludedCharacters.Contains(x) Then
                Return $"{inputInformation} contains excluded character '{x}', please re-enter {inputInformation} refraining from using this character."
            End If
        Next
        Return ""

    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Converts 9 to 09, 3 to 03, 10 to 10 for dates and others
    Function ConvertTo2DString(num As Integer) As String
        Dim strNum As String = Convert.ToString(num)
        If strNum.Length() = 1 Then
            strNum = $"0{strNum}"
        End If
        Return strNum
    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Returns days in a month, including leap year
    Function DaysInAMonth(strMonth As String, Optional intYear As Integer = 2023) As Integer
        Dim num As Integer
        Select Case strMonth
            Case "January"
                num = 31
            Case "February"
                If intYear Mod 4 = 0 Then
                    num = 29
                Else
                    num = 28
                End If
            Case "March"
                num = 31
            Case "April"
                num = 30
            Case "May"
                num = 31
            Case "June"
                num = 30
            Case "July"
                num = 31
            Case "August"
                num = 31
            Case "September"
                num = 30
            Case "October"
                num = 31
            Case "November"
                num = 30
            Case "December"
                num = 31
            Case Else
                num = 0
        End Select
        Return num
    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Turns day to index for calendar
    Function DayToIndex(strDay As String) As Integer
        Dim num As Integer
        Select Case strDay
            Case "Sunday"
                num = 1
            Case "Monday"
                num = 2
            Case "Tuesday"
                num = 3
            Case "Wednesday"
                num = 4
            Case "Thursday"
                num = 5
            Case "Friday"
                num = 6
            Case "Saturday"
                num = 7

        End Select
        Return num
    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''int value to month string
    Function IndexToMonth(intMonth As Integer) As String
        Dim strMonth As String
        Select Case intMonth
            Case 1
                strMonth = "January"
            Case 2
                strMonth = "February"
            Case 3
                strMonth = "March"
            Case 4
                strMonth = "April"
            Case 5
                strMonth = "May"
            Case 6
                strMonth = "June"
            Case 7
                strMonth = "July"
            Case 8
                strMonth = "August"
            Case 9
                strMonth = "September"
            Case 10
                strMonth = "October"
            Case 11
                strMonth = "November"
            Case 12
                strMonth = "December"
            Case Else
                strMonth = "Out of range"
        End Select
        Return strMonth
    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''month string to int value
    Function MonthToIndex(strMonth As String) As Integer
        Dim intMonth As Integer
        Select Case strMonth
            Case "January"
                intMonth = 1
            Case "February"
                intMonth = 2
            Case "March"
                intMonth = 3
            Case "April"
                intMonth = 4
            Case "May"
                intMonth = 5
            Case "June"
                intMonth = 6
            Case "July"
                intMonth = 7
            Case "August"
                intMonth = 8
            Case "September"
                intMonth = 9
            Case "October"
                intMonth = 10
            Case "November"
                intMonth = 11
            Case "December"
                intMonth = 12
            Case Else
                intMonth = -1
        End Select
        Return intMonth
    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Hash funtion
    Public Function Hash(pass As String) As Integer
        Dim num As Integer = 0
        Dim prime As Integer = 7
        For Each letter In pass
            If num < 165191049 Then
                num = (num * prime) + letterToNum(letter)
            Else
                num += letterToNum(letter)
            End If
        Next


        Return num
    End Function

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''Random letter assignment for extra complexity for hash
    Private Function letterToNum(par As Char) As Integer
        Dim num As Integer
        Select Case par
            Case "A"
                num = 47
            Case "B"
                num = 42
            Case "C"
                num = 89
            Case "D"
                num = 60
            Case "E"
                num = 76
            Case "F"
                num = 67
            Case "G"
                num = 7
            Case "H"
                num = 68
            Case "I"
                num = 10
            Case "J"
                num = 21
            Case "K"
                num = 80
            Case "L"
                num = 65
            Case "M"
                num = 48
            Case "N"
                num = 94
            Case "O"
                num = 74
            Case "P"
                num = 13
            Case "Q"
                num = 61
            Case "R"
                num = 8
            Case "S"
                num = 20
            Case "T"
                num = 35
            Case "U"
                num = 6
            Case "V"
                num = 27
            Case "W"
                num = 57
            Case "X"
                num = 66
            Case "Y"
                num = 32
            Case "Z"
                num = 28
            Case "a"
                num = 24
            Case "b"
                num = 84
            Case "c"
                num = 53
            Case "d"
                num = 18
            Case "e"
                num = 59
            Case "f"
                num = 88
            Case "g"
                num = 19
            Case "h"
                num = 79
            Case "i"
                num = 81
            Case "j"
                num = 23
            Case "k"
                num = 1
            Case "l"
                num = 77
            Case "m"
                num = 45
            Case "n"
                num = 26
            Case "o"
                num = 29
            Case "p"
                num = 83
            Case "q"
                num = 39
            Case "r"
                num = 92
            Case "s"
                num = 87
            Case "t"
                num = 97
            Case "u"
                num = 12
            Case "v"
                num = 36
            Case "w"
                num = 62
            Case "x"
                num = 3
            Case "y"
                num = 78
            Case "z"
                num = 44
            Case "0"
                num = 15
            Case "1"
                num = 31
            Case "2"
                num = 75
            Case "3"
                num = 17
            Case "4"
                num = 73
            Case "5"
                num = 72
            Case "6"
                num = 93
            Case "7"
                num = 96
            Case "8"
                num = 91
            Case "9"
                num = 82
            Case "!"
                num = 98
            Case "@"
                num = 11
            Case "#"
                num = 63
            Case "$"
                num = 90
            Case "%"
                num = 46
            Case "&"
                num = 64
            Case "*"
                num = 30
            Case "("
                num = 38
            Case ")"
                num = 43
            Case "-"
                num = 99
            Case "+"
                num = 52
        End Select
        Return num
    End Function

End Module
